# Architecture

Native Kotlin 2.2.21 + Compose BOM 2025.12.01/Material 3, AGP 8.13.2, Gradle 8.13, min SDK 24 and compile/target SDK 36. Java time uses core-library desugaring. No database/backend/auth needed.

Pure game: Models, Evaluator, GameRules, WordBank, Stats and AdPolicy. Two-pass duplicate evaluation reserves exact positions before distributing residual frequency. Enum ranks preserve strongest keyboard clues. The versioned SHA-256 daily seed includes local date and length, over frozen ordered answer pools. Practice excludes recent answers.

GameRepository owns one serializable snapshot including active route, input, practice session, daily map, settings, deduplicated completed records, recent answers and ad caps. SnapshotStore is injected for JVM tests. AndroidStore commits the complete JSON atomically with SharedPreferences.commit; writes finish before in-memory state changes. A lightweight document is sufficient for this small single-process game; a database is not necessary. Full commit on every typed letter prioritizes interrupted-session correctness. Very long histories can justify a later indexed migration; preserve IDs and daily-v1 answer semantics.

Compose app mirrors repository state after successful actions and uses saveable menu selections. Foreground/15-second/input checks handle local date changes. UI state restores from disk after activity/process recreation. AdsCoordinator owns one activity's UMP/ad callbacks, disposes loaded objects, gates all loads and implements opt-in transitions. Release-disabled mode keeps SDK binaries but initiates no application requests. All external ads behavior requires device QA.
