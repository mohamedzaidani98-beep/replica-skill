# Findings and remaining checks
Fixed during implementation: environment lacked a Java compiler (installed verified JDK); Android tooling needed writable cache/config paths; daily UI labels needed to use the active puzzle's length and refresh the local date; shared ads-ready state needed to remain observable across activity recreation; instrumentation now turns ads off before Activity launch.

No outstanding reproduced compilation/unit-test/lint errors are known. SDK lifecycle/ad display behavior, device-specific layouts, region consent, TalkBack and real process death remain to check, not fictitious reproduced bugs. Exact user PNG assets are unavailable in the filesystem; vector fallback is explicit. Source and packaged artifact scans are documented in replica/audit.json.
