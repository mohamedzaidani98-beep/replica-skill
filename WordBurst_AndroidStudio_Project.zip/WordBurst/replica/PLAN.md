# WordBurst implementation plan

Fixed brand: WordBurst, com.zaidani.wordburst, English, supplied blue/red/green/yellow palette and tagline. Native Kotlin/Compose, SDK 36, min SDK 24, no backend. Adapt the local MIT Replica framework; do not run Claude commands.

1. Inspect skills, permitted reference and official SDK metadata. Write independent scope and visual system. Public Play listing and developers.google.com documentation requests returned HTTP 403; use the supplied brief, Maven metadata and official sample source where accessible. Do not infer unseen app details.
2. Write a pure two-pass word evaluator and state transitions. Author common answer pools for 4/5/6 letters, and include a separate licensed validation dictionary. Deterministic versioned local-date daily selection; do not repeat practice answers immediately. Save snapshots, typed input, per-day records and stats atomically on every action.
3. Build responsive Compose menu, selectors, QWERTY keyboard, clue grid with text symbols, tutorial, settings, stats and results. Persist current screen/session across recreation. Provide safe optional hints and spoiler-free sharing. Portrait and landscape remain supported.
4. Integrate official test-only debug AdMob and UMP; release ads default disabled without production IDs. Gate every ad request on consent. No gameplay banners; opt-in post-practice interstitial with persisted frequency cap. Privacy Options available when required.
5. Run JVM tests, lint, debug APK, unsigned AAB, instrumentation compilation, manifest/language/assets scans. Distinguish code inspection from real device/network behavior. Zip clean root including wrapper, docs, license and corpus. Extract and rebuild to verify export.

Images are visible in chat but no binary PNG attachments are exposed in the workspace. Use a clearly documented original vector W/B adaptive/monochrome fallback; do not claim the supplied raster binaries were included. Keep asset replacement slots documented.
