# Independent recon and scope

Sources: detailed user specification; local Replica README/SKILL.md files and MIT license (copyright 2026 Jake Schincariol); supplied WordBurst artwork visible in chat; public concept URL https://play.google.com/store/apps/details?id=com.apollogames.wordle (request returned HTTP 403); Google SDK Maven metadata and accessible official sample sources. No reference binary, source, gated data, images, API or word corpus was inspected or copied. No screenshot layout parity is claimed.

S01 menu with mode/length/difficulty; S02 practice/daily grid and keyboard; S03 completed round and sharing; S04 tutorial with authored APPLE/ALLEY example; S05 stats; S06 settings/privacy. F01 practice to result/new round; F02 daily save/resume/local rollover; F03 lifecycle restore; F04 settings/privacy; F05 optional post-practice ad. Daily and practice share an engine but maintain distinct IDs and records. The user's scope and brand choices already resolve platform/audience/slice; no confirmation is needed.

Risks: duplicate frequency accounting, deterministic daily pool stability, atomic record updates, SDK callback eligibility, accessible compact layouts. Out of scope: backend, login, reference proprietary corpus/assets, social accounts, production publishing and trademark clearance.
