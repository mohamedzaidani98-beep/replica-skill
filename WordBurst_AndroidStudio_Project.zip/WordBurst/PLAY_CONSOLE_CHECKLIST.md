# Google Play release checklist

- Read QA_REPORT.md and complete every phone test (small screen, font scale, TalkBack, landscape/rotation, process kill/resume, local midnight, offline, all result/navigation paths).
- Use package com.zaidani.wordburst, display name WordBurst, versionCode 1/versionName 1.0.0 for first release. Increment versionCode for later uploads. Compile/target SDK 36 are configured; check the current Play requirement again at submission.
- Review and clear the fixed brand before public release; no trademark/store availability claim is made. Insert the supplied original raster assets if required; see ASSETS.md. Use real screenshots from this app, not reference screenshots.
- Build and retain the signed release AAB and mapping.txt. Generate the upload key outside the project using Android Studio's signed-bundle wizard. Back it up securely; enable Play App Signing. No keystore/password belongs in the archive.
- Start with the default ads-disabled release or configure production IDs and complete AdMob/UMP setup; never monetize debug test IDs. Test consent/privacy options and ad policies on devices.
- Review merged permissions, dependency disclosures, privacy policy/support URL, Data safety, ads declaration, target audience, content rating, country availability and any applicable new-developer testing requirement. Audit the licensed word data for audience suitability; accepted dictionaries may contain adult vocabulary even though answer pools were curated.
- Upload to internal testing, install from Play, review automated prelaunch reports, crash/ANR behavior and 16 KB native-library compatibility. Check any SDK native libraries on supported devices; do not assume store validation from an AAB build.
- Complete your required testing track and production rollout review. This project does not guarantee Play acceptance or perform publication.
