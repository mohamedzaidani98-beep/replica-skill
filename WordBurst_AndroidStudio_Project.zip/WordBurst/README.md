# WordBurst

See [README_FIRST.md](README_FIRST.md) for setup, play, builds, signing and release steps.
