# Changelog

## 1.0.0 / versionCode 1
- Original native WordBurst UI, 4/5/6-letter practice and daily-v1 puzzles.
- Frequency-aware duplicate handling, no keyboard clue downgrade, one free safe hint and spoiler-free sharing.
- Atomic saved input/session/history/settings and date-based daily streaks.
- English Wordnik MIT validation dictionary with separately curated common answers.
- Consent-gated Google debug test ads and disabled-by-default release ads, optional player toggle and persisted interstitial frequency limits.
- Adaptive W/B and monochrome vector fallback icons; supplied PNG binaries are pending file availability.
- JVM and Android UI tests, release/privacy/ads documentation and export verification.
