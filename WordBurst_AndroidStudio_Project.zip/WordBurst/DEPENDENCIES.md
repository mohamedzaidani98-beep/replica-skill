# Dependencies and licenses

Direct application dependencies: Kotlin/serialization 2.2.21 + JSON 1.9.0, AndroidX Activity Compose 1.11.0/Lifecycle 2.9.4, Compose BOM 2025.12.01 (UI/foundation/Material 3), Google Mobile Ads 25.5.0, UMP 4.0.0, core-library desugaring 2.1.5. Build: AGP 8.13.2, Gradle 8.13 and JDK 17+. Tests: JUnit 4.13.2 (EPL-1.0), Hamcrest (BSD-3-Clause), AndroidX Test runner 1.7.0/ext JUnit 1.3.0 and Compose test (Apache-2.0).

Kotlin/AndroidX/Gradle/AGP are Apache-2.0. Google proprietary SDK components are governed by their published SDK terms (see each artifact POM), not a blanket claim of open-source licensing. Ads transitively bundles Google measurement components and WorkManager; no separate app analytics integration or analytics events are implemented. SDK disclosures still apply. Wordnik data: MIT; local framework adaptation: MIT notice included. System fonts and procedural tones only.

## Resolved release artifacts

Generated from the successful Gradle/lint dependency model and cached upstream POM license metadata. Missing POM license declarations are explicitly marked; check upstream terms and required notices before distribution.

| Artifact | Declared license |
| --- | --- |
| androidx.activity:activity-compose:1.11.0 | The Apache Software License, Version 2.0 |
| androidx.activity:activity-ktx:1.11.0 | The Apache Software License, Version 2.0 |
| androidx.activity:activity:1.11.0 | The Apache Software License, Version 2.0 |
| androidx.annotation:annotation-experimental:1.4.1 | The Apache Software License, Version 2.0 |
| androidx.annotation:annotation-jvm:1.9.1 | The Apache Software License, Version 2.0 |
| androidx.appcompat:appcompat-resources:1.4.1 | The Apache Software License, Version 2.0 |
| androidx.arch.core:core-common:2.2.0 | The Apache Software License, Version 2.0 |
| androidx.arch.core:core-runtime:2.2.0 | The Apache Software License, Version 2.0 |
| androidx.autofill:autofill:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.browser:browser:1.8.0 | The Apache Software License, Version 2.0 |
| androidx.collection:collection-jvm:1.5.0 | The Apache Software License, Version 2.0 |
| androidx.collection:collection-ktx:1.5.0 | The Apache Software License, Version 2.0 |
| androidx.compose.animation:animation-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.animation:animation-core-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.foundation:foundation-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.foundation:foundation-layout-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.material3:material3-android:1.4.0 | The Apache Software License, Version 2.0 |
| androidx.compose.material:material-ripple-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.runtime:runtime-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.runtime:runtime-annotation-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.runtime:runtime-retain-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.runtime:runtime-saveable-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.ui:ui-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.ui:ui-geometry-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.ui:ui-graphics-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.ui:ui-text-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.ui:ui-tooling-preview-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.ui:ui-unit-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.compose.ui:ui-util-android:1.10.0 | The Apache Software License, Version 2.0 |
| androidx.concurrent:concurrent-futures:1.1.0 | The Apache Software License, Version 2.0 |
| androidx.core:core-ktx:1.16.0 | The Apache Software License, Version 2.0 |
| androidx.core:core-viewtree:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.core:core:1.16.0 | The Apache Software License, Version 2.0 |
| androidx.customview:customview-poolingcontainer:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.customview:customview:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.datastore:datastore-core:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.datastore:datastore:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.documentfile:documentfile:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.dynamicanimation:dynamicanimation:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.emoji2:emoji2:1.4.0 | The Apache Software License, Version 2.0 |
| androidx.fragment:fragment:1.1.0 | The Apache Software License, Version 2.0 |
| androidx.graphics:graphics-path:1.0.1 | The Apache Software License, Version 2.0 |
| androidx.interpolator:interpolator:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.legacy:legacy-support-core-utils:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-common-java8:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-common-jvm:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-livedata-core-ktx:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-livedata-core:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-livedata:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-process:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-runtime-android:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-runtime-compose-android:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-runtime-ktx-android:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-service:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-viewmodel-android:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-viewmodel-ktx:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-viewmodel-savedstate-android:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.lifecycle:lifecycle-viewmodel:2.9.4 | The Apache Software License, Version 2.0 |
| androidx.loader:loader:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.localbroadcastmanager:localbroadcastmanager:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.print:print:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.privacysandbox.ads:ads-adservices-java:1.0.0-beta05 | The Apache Software License, Version 2.0 |
| androidx.privacysandbox.ads:ads-adservices:1.0.0-beta05 | The Apache Software License, Version 2.0 |
| androidx.profileinstaller:profileinstaller:1.4.0 | The Apache Software License, Version 2.0 |
| androidx.room:room-common:2.2.5 | The Apache Software License, Version 2.0 |
| androidx.room:room-runtime:2.2.5 | The Apache Software License, Version 2.0 |
| androidx.savedstate:savedstate-android:1.3.2 | The Apache Software License, Version 2.0 |
| androidx.savedstate:savedstate-compose-android:1.3.2 | The Apache Software License, Version 2.0 |
| androidx.savedstate:savedstate-ktx:1.3.2 | The Apache Software License, Version 2.0 |
| androidx.sqlite:sqlite-framework:2.1.0 | The Apache Software License, Version 2.0 |
| androidx.sqlite:sqlite:2.1.0 | The Apache Software License, Version 2.0 |
| androidx.startup:startup-runtime:1.1.1 | The Apache Software License, Version 2.0 |
| androidx.tracing:tracing:1.2.0 | The Apache Software License, Version 2.0 |
| androidx.transition:transition:1.6.0 | The Apache Software License, Version 2.0 |
| androidx.vectordrawable:vectordrawable-animated:1.1.0 | The Apache Software License, Version 2.0 |
| androidx.vectordrawable:vectordrawable:1.1.0 | The Apache Software License, Version 2.0 |
| androidx.versionedparcelable:versionedparcelable:1.1.1 | The Apache Software License, Version 2.0 |
| androidx.viewpager:viewpager:1.0.0 | The Apache Software License, Version 2.0 |
| androidx.webkit:webkit:1.12.1 | The Apache Software License, Version 2.0 |
| androidx.window:window-core-android:1.5.0 | The Apache Software License, Version 2.0 |
| androidx.window:window:1.5.0 | The Apache Software License, Version 2.0 |
| androidx.work:work-runtime:2.7.0 | The Apache Software License, Version 2.0 |
| com.google.android.gms:play-services-ads-api:25.5.0 | Android Software Development Kit License |
| com.google.android.gms:play-services-ads-identifier:18.0.0 | Android Software Development Kit License |
| com.google.android.gms:play-services-ads:25.5.0 | Android Software Development Kit License |
| com.google.android.gms:play-services-appset:16.0.1 | Android Software Development Kit License |
| com.google.android.gms:play-services-base:18.0.0 | Android Software Development Kit License |
| com.google.android.gms:play-services-basement:18.9.0 | Android Software Development Kit License |
| com.google.android.gms:play-services-measurement-base:20.1.2 | Android Software Development Kit License |
| com.google.android.gms:play-services-measurement-sdk-api:20.1.2 | Android Software Development Kit License |
| com.google.android.gms:play-services-tasks:18.2.0 | Android Software Development Kit License |
| com.google.android.play:hsdp:2.0.1 | Android Software Development Kit License |
| com.google.android.ump:user-messaging-platform:4.0.0 | Android Software Development Kit License |
| com.google.code.findbugs:jsr305:3.0.2 | The Apache Software License, Version 2.0 |
| com.google.errorprone:error_prone_annotations:2.11.0 | Apache 2.0 |
| com.google.guava:failureaccess:1.0.1 | Apache-2.0 (Guava parent/upstream project) |
| com.google.guava:guava:31.1-android | Apache-2.0 (Guava parent/upstream project) |
| com.google.guava:listenablefuture:9999.0-empty-to-avoid-conflict-with-guava | Apache-2.0 (Guava parent/upstream project) |
| com.google.j2objc:j2objc-annotations:1.3 | The Apache Software License, Version 2.0 |
| org.checkerframework:checker-qual:3.12.0 | The MIT License |
| org.jetbrains.kotlin:kotlin-stdlib:2.2.21 | Apache-2.0 |
| org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0 | The Apache Software License, Version 2.0 |
| org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm:1.9.0 | The Apache Software License, Version 2.0 |
| org.jetbrains.kotlinx:kotlinx-serialization-core-jvm:1.9.0 | Apache-2.0 |
| org.jetbrains.kotlinx:kotlinx-serialization-json-jvm:1.9.0 | Apache-2.0 |
| org.jetbrains:annotations:23.0.0 | The Apache Software License, Version 2.0 |
| org.jspecify:jspecify:1.0.0 | The Apache License, Version 2.0 |
