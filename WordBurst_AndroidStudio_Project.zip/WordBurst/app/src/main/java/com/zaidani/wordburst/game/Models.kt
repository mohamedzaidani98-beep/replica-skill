package com.zaidani.wordburst.game
import kotlinx.serialization.Serializable
@Serializable enum class Mark { ABSENT, PRESENT, CORRECT }
@Serializable enum class Mode { PRACTICE, DAILY }
@Serializable enum class Difficulty { RELAXED, STANDARD, TRICKY }
@Serializable data class Guess(val word: String,val marks: List<Mark>)
@Serializable data class Puzzle(
 val id: String,val mode: Mode,val length: Int,val difficulty: Difficulty,val answer: String,val date: String,
 val guesses: List<Guess> = emptyList(),val input: String="",val hintIndex: Int?=null
) {
 val won get()=guesses.any { it.word==answer }
 val finished get()=won || guesses.size>=6
 val keyboard: Map<Char,Mark> get() {
  val out=mutableMapOf<Char,Mark>()
  guesses.forEach { guess -> guess.word.forEachIndexed { i,c -> if((out[c]?.ordinal ?: -1)<guess.marks[i].ordinal) out[c]=guess.marks[i] } }
  return out
 }
}
@Serializable data class RoundRecord(val id: String,val mode: Mode,val date: String,val length: Int,val won: Boolean,val attempts: Int,val hinted: Boolean)
@Serializable data class Settings(val sound: Boolean=false,val haptics: Boolean=true,val theme: String="system",val contrast: Boolean=false,val ads: Boolean=true)
@Serializable data class Snapshot(
 val schema: Int=1,val practice: Puzzle?=null,val daily: Map<String,Puzzle> = emptyMap(),val records: List<RoundRecord> = emptyList(),
 val activeId: String?=null,val screen: String="menu",val settings: Settings=Settings(),val recent: List<String> = emptyList(),
 val practiceCompletions: Int=0,val lastAdRound: Int=0,val lastAdTime: Long=0
)
