package com.zaidani.wordburst.ui

import android.app.Activity
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusTarget
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.zaidani.wordburst.ads.*
import com.zaidani.wordburst.data.*
import com.zaidani.wordburst.game.*
import kotlinx.coroutines.delay
import java.time.LocalDate

@Composable fun WordBurstApp(activity: Activity) {
 val repo=remember { GameRepository(AndroidStore(activity.applicationContext),loadWords(activity.assets)) }
 var state by remember { mutableStateOf(repo.state) }
 var message by remember { mutableStateOf("") }
 var localDate by remember { mutableStateOf(LocalDate.now()) }
 var length by rememberSaveable { mutableIntStateOf(5) }
 var difficulty by rememberSaveable { mutableStateOf(Difficulty.STANDARD) }
 var abandonDialog by remember { mutableStateOf(false) }
 val ads=remember(activity) { AdsCoordinator(activity) }
 val feedback=remember { Feedback() }; val view=LocalView.current
 val lifecycle=LocalLifecycleOwner.current.lifecycle
 fun act(action: ()->Unit) { runCatching { action(); state=repo.state }.onFailure { message="Progress could not be saved. Check device storage and try again." } }
 fun navigate(screen: String) { message=""; act { repo.screen(screen) } }
 fun start(mode: Mode) { message=""; act { repo.start(mode,length,difficulty) } }
 fun nextPractice() { val p=repo.current ?: return; message=""; act { repo.start(Mode.PRACTICE,p.length,p.difficulty) } }
 fun input(key: String) {
  if(key=="ENTER") act {
   message=repo.submit().orEmpty()
   if(message.isEmpty()) { repo.current?.let { feedback.submit(view,repo.state.settings,it.won) } }
  } else act { repo.key(key) }
 }
 DisposableEffect(ads) { ads.launch(state.settings.ads); onDispose { ads.dispose(); feedback.dispose() } }
 DisposableEffect(lifecycle) {
  val observer=LifecycleEventObserver { _,event -> if(event==Lifecycle.Event.ON_RESUME) act { localDate=LocalDate.now(); if(repo.rollover()) message="A new local day has started." } }
  lifecycle.addObserver(observer); onDispose { lifecycle.removeObserver(observer) }
 }
 LaunchedEffect(state.activeId,state.screen) {
  while(true) { delay(15_000); localDate=LocalDate.now(); if(repo.current?.mode==Mode.DAILY && state.screen=="game") act { if(repo.rollover()) message="A new local day has started." } }
 }
 val current=repo.current
 LaunchedEffect(current?.finished,state.practiceCompletions,ads.allowed,ads.status) {
  if(AdPolicy.eligible(state,current,System.currentTimeMillis())) ads.prepareInterstitial()
 }
 BackHandler(state.screen!="menu") { navigate("menu") }
 val focus=remember { FocusRequester() }
 LaunchedEffect(state.screen) { if(state.screen=="game") focus.requestFocus() }
 WordBurstTheme(state.settings) {
  Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background) {
   Box(Modifier.fillMaxSize().safeDrawingPadding(),contentAlignment=Alignment.TopCenter) {
    Column(Modifier.widthIn(max=540.dp).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=16.dp,vertical=12.dp).onPreviewKeyEvent { event ->
     if(state.screen!="game" || repo.current?.finished!=false || event.type!=KeyEventType.KeyUp) false
     else when {
      event.key==Key.Enter || event.key==Key.NumPadEnter -> { input("ENTER"); true }
      event.key==Key.Backspace -> { input("⌫"); true }
      event.utf16CodePoint.toChar().uppercaseChar() in 'A'..'Z' -> { input(event.utf16CodePoint.toChar().uppercaseChar().toString()); true }
      else -> false
     }
    }.focusRequester(focus).focusTarget(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)) {
     if(state.screen!="menu") Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
      TextButton(onClick={navigate("menu")}) { Text("‹ Menu") }
      Text("WordBurst",fontWeight=FontWeight.ExtraBold,style=MaterialTheme.typography.titleMedium)
     }
     when(state.screen) {
      "menu" -> {
       Spacer(Modifier.height(12.dp)); BrandHeader()
       Text("Guess the word. Feel the burst.",style=MaterialTheme.typography.titleMedium)
       Text("Small words. Bright discoveries.",style=MaterialTheme.typography.bodyMedium)
       ModePicker(length,difficulty,{length=it},{difficulty=it})
       Button(onClick={ if(state.practice?.finished==false) abandonDialog=true else start(Mode.PRACTICE) },modifier=Modifier.fillMaxWidth().heightIn(min=52.dp)) { Text("Play") }
       if(state.practice!=null) OutlinedButton(onClick={message=""; act { repo.resumePractice() }},modifier=Modifier.fillMaxWidth()) { Text(if(state.practice?.finished==true) "Last practice result" else "Resume practice") }
       Button(onClick={start(Mode.DAILY)},modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),colors=ButtonDefaults.buttonColors(containerColor=Brand.Yellow,contentColor=Brand.Ink)) { Text("Daily Challenge · $length letters") }
       Text("One saved puzzle per date and length · $localDate",style=MaterialTheme.typography.labelMedium)
       Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick={navigate("tutorial")},modifier=Modifier.weight(1f)) { Text("How to Play") }
        OutlinedButton(onClick={navigate("statistics")},modifier=Modifier.weight(1f)) { Text("Statistics") }
       }
       TextButton(onClick={navigate("settings")}) { Text("Settings & Privacy") }
       OptionalBanner(ads,state.settings.ads)
      }
      "game" -> if(current!=null) {
       Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
        Text(if(current.mode==Mode.DAILY) "Daily · ${current.date}" else "Practice · ${current.difficulty.name.lowercase().replaceFirstChar { it.uppercase() }}",style=MaterialTheme.typography.labelLarge)
        Text("${current.guesses.size} / 6 attempts",style=MaterialTheme.typography.labelLarge)
       }
       ClueGrid(current,state.settings.contrast)
       Text("✓ correct place    ↔ elsewhere    × unmatched",style=MaterialTheme.typography.labelMedium)
       if(current.finished) {
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
         Text(if(current.won) "That's a WordBurst!" else "A word for next time",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
         Text("The word was ${current.answer}.",style=MaterialTheme.typography.titleMedium)
         Text(if(current.won) "Solved in ${current.guesses.size} of 6 attempts${if(current.hintIndex!=null) " · hint used" else ""}." else "Every clue is a little practice. Try another round.")
         Button(onClick={activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,Stats.share(current)) },"Share your WordBurst"))},modifier=Modifier.fillMaxWidth()) { Text("Share result") }
         if(current.mode==Mode.PRACTICE) {
          Button(onClick={nextPractice()},modifier=Modifier.fillMaxWidth()) { Text("Next practice puzzle") }
          if(AdPolicy.eligible(state,current,System.currentTimeMillis()) && ads.interstitialReady && ads.canLoad()) OutlinedButton(onClick={
           if(AdPolicy.eligible(repo.state,repo.current,System.currentTimeMillis())) ads.showOptIn(onShown={act { repo.markAdShown(System.currentTimeMillis()) }},onContinue={nextPractice()}) else nextPractice()
          },modifier=Modifier.fillMaxWidth()) { Text("Next with an optional ad") }
         } else Text("Today's ${current.length}-letter result is saved. Try another length or return tomorrow.")
        } }
        OutlinedButton(onClick={navigate("menu")}) { Text("Back to menu") }
       } else {
        current.hintIndex?.let { index -> Text("Hint: letter ${index+1} is ${current.answer[index]}.",style=MaterialTheme.typography.titleMedium) }
        Text(message.ifEmpty { "Type a ${current.length}-letter word, then enter your guess." },color=if(message.isEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,modifier=Modifier.fillMaxWidth().semantics { liveRegion=LiveRegionMode.Polite })
        Keyboard(current,true,::input)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
         TextButton(onClick={act { repo.hint() }},enabled=current.hintIndex==null) { Text("Reveal one letter") }
         TextButton(onClick={navigate("menu")}) { Text("Save & leave") }
        }
       }
      } else Text("No round is open. Return to the menu to play.")
      "tutorial" -> Tutorial()
      "statistics" -> Statistics(state,localDate)
      "settings" -> SettingsScreen(state.settings,ads,{ new -> act { repo.settings(new) }; ads.setPlayerEnabled(new.ads) },{ ads.privacyOptions { message=it ?: "Privacy choices updated." } })
      else -> TextButton(onClick={navigate("menu")}) { Text("Back to menu") }
     }
     if(message.isNotEmpty() && (state.screen!="game" || current?.finished==true)) Text(message,color=MaterialTheme.colorScheme.error,modifier=Modifier.semantics { liveRegion=LiveRegionMode.Polite })
     Spacer(Modifier.height(12.dp))
    }
   }
  }
  if(abandonDialog) AlertDialog(onDismissRequest={abandonDialog=false},title={Text("Start a fresh round?")},text={Text("Your unfinished practice puzzle will be replaced. Daily records stay saved.")},confirmButton={TextButton(onClick={abandonDialog=false; start(Mode.PRACTICE)}) { Text("Start new") }},dismissButton={TextButton(onClick={abandonDialog=false; act { repo.resumePractice() }}) { Text("Resume instead") }})
 }
}
