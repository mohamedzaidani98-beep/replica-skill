package com.zaidani.wordburst.data
import android.content.Context
import android.content.res.AssetManager
import com.zaidani.wordburst.game.WordBank
class AndroidStore(context: Context): SnapshotStore {
 private val prefs=context.getSharedPreferences("wordburst_state_v1",Context.MODE_PRIVATE)
 override fun read()=prefs.getString("snapshot",null)
 override fun write(value: String) { check(prefs.edit().putString("snapshot",value).commit()) { "WordBurst could not save progress. Free device storage and try again." } }
}
fun loadWords(assets: AssetManager): WordBank {
 fun lines(name: String)=assets.open("words/$name").bufferedReader().use { it.readLines().filter { line -> line.isNotBlank() }.map { line -> line.trim().uppercase(java.util.Locale.ROOT) } }
 return WordBank((4..6).associateWith { lines("answers_$it.txt") },lines("accepted.txt").toSet())
}
