package com.zaidani.wordburst.ui
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaidani.wordburst.game.*
fun markLabel(mark: Mark)=when(mark) { Mark.CORRECT->"correct place"; Mark.PRESENT->"in the word, different place"; Mark.ABSENT->"not matched in the word" }
fun markSymbol(mark: Mark)=when(mark) { Mark.CORRECT->"✓"; Mark.PRESENT->"↔"; Mark.ABSENT->"×" }
fun markColor(mark: Mark)=when(mark) { Mark.CORRECT->Brand.Green; Mark.PRESENT->Brand.Yellow; Mark.ABSENT->Brand.Ink }
@Composable fun ClueGrid(puzzle: Puzzle,contrast: Boolean) {
 Column(Modifier.fillMaxWidth().testTag("clue-grid").semantics { contentDescription="${puzzle.length} letter puzzle, six attempts" },verticalArrangement=Arrangement.spacedBy(5.dp)) {
  repeat(6) { row ->
   val submitted=puzzle.guesses.getOrNull(row)
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp,Alignment.CenterHorizontally)) {
    repeat(puzzle.length) { column ->
     val mark=submitted?.marks?.get(column)
     val letter=submitted?.word?.get(column)?.toString() ?: if(row==puzzle.guesses.size && !puzzle.finished) puzzle.input.getOrNull(column)?.toString().orEmpty() else ""
     val bg by animateColorAsState(mark?.let { markColor(it) } ?: MaterialTheme.colorScheme.surface,tween(220,delayMillis=column*40),label="Tile reveal")
     val textColor=if(mark==Mark.ABSENT) Brand.White else if(mark!=null) Brand.Ink else MaterialTheme.colorScheme.onSurface
     Column(Modifier.weight(1f).heightIn(min=52.dp).background(bg,RoundedCornerShape(10.dp)).border(if(contrast) 2.dp else 1.dp,if(row==puzzle.guesses.size && letter.isNotBlank()) Brand.Blue else MaterialTheme.colorScheme.outline,RoundedCornerShape(10.dp)).padding(vertical=3.dp).clearAndSetSemantics { contentDescription="Attempt ${row+1}, letter ${column+1}: ${letter.ifEmpty { "empty" }}${mark?.let { ", ${markLabel(it)}" } ?: ""}" },horizontalAlignment=Alignment.CenterHorizontally) {
      Text(letter.ifEmpty { " " },color=textColor,fontSize=24.sp,fontWeight=FontWeight.ExtraBold,lineHeight=28.sp)
      Text(mark?.let { markSymbol(it) } ?: " ",color=textColor,fontSize=12.sp,lineHeight=14.sp)
     }
    }
   }
  }
 }
}
@Composable fun Keyboard(puzzle: Puzzle,enabled: Boolean,onKey: (String)->Unit) {
 Column(Modifier.fillMaxWidth().testTag("keyboard"),verticalArrangement=Arrangement.spacedBy(6.dp)) {
  listOf("QWERTYUIOP","ASDFGHJKL","ZXCVBNM").forEach { row ->
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
    row.forEach { key ->
     val mark=puzzle.keyboard[key]
     val container=mark?.let { markColor(it) } ?: MaterialTheme.colorScheme.surface
     val foreground=if(mark==Mark.ABSENT) Brand.White else if(mark!=null) Brand.Ink else MaterialTheme.colorScheme.onSurface
     Surface(onClick={onKey(key.toString())},enabled=enabled,shape=RoundedCornerShape(8.dp),color=container,contentColor=foreground,modifier=Modifier.weight(1f).heightIn(min=48.dp).semantics { contentDescription="$key${mark?.let { ", ${markLabel(it)}" } ?: ", not tried"}" },border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.outline)) {
      Column(Modifier.padding(vertical=6.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) { Text(key.toString(),fontSize=16.sp,fontWeight=FontWeight.Bold); if(mark!=null) Text(markSymbol(mark),fontSize=10.sp) }
     }
    }
   }
  }
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
   OutlinedButton(onClick={onKey("⌫")},enabled=enabled,modifier=Modifier.weight(1f).heightIn(min=48.dp).semantics { contentDescription="Delete last letter" }) { Text("Delete") }
   Button(onClick={onKey("ENTER")},enabled=enabled,modifier=Modifier.weight(1f).heightIn(min=48.dp)) { Text("Enter guess") }
  }
 }
}
