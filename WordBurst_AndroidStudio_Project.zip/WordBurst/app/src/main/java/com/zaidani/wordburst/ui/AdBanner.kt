package com.zaidani.wordburst.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.*
import com.zaidani.wordburst.ads.*
@Composable fun OptionalBanner(ads: AdsCoordinator,playerEnabled: Boolean) {
 val canLoad=ads.canLoad()
 if(!AdConfig.enabled || !playerEnabled || !canLoad) return
 var adView by remember { mutableStateOf<AdView?>(null) }
 DisposableEffect(Unit) { onDispose { adView?.destroy(); adView=null } }
 // Separate region with fixed reserved height; never over a keyboard or a game clue.
 HorizontalDivider(Modifier.padding(top=24.dp,bottom=12.dp))
 Text("Advertisement · ${if(com.zaidani.wordburst.BuildConfig.DEBUG) "Google test ad" else "optional sponsor"}",style=MaterialTheme.typography.labelSmall)
 Box(Modifier.fillMaxWidth().height(60.dp),contentAlignment=androidx.compose.ui.Alignment.Center) {
  AndroidView(factory={ context -> AdView(context).apply { setAdSize(AdSize.BANNER); adUnitId=AdConfig.BANNER_AD_UNIT_ID; adView=this; if(ads.canLoad()) loadAd(AdRequest.Builder().build()) } },modifier=Modifier.width(320.dp).height(50.dp))
 }
}
