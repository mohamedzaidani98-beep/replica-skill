package com.zaidani.wordburst.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.runtime.*
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.*
import com.zaidani.wordburst.BuildConfig
import java.util.concurrent.atomic.AtomicBoolean

object AdConfig {
 val enabled=BuildConfig.ADS_ENABLED
 val ADMOB_APP_ID=BuildConfig.ADMOB_APP_ID
 val BANNER_AD_UNIT_ID=BuildConfig.BANNER_AD_UNIT_ID
 val INTERSTITIAL_AD_UNIT_ID=BuildConfig.INTERSTITIAL_AD_UNIT_ID
}
class AdsCoordinator(private val activity: Activity) {
 private val consent=UserMessagingPlatform.getConsentInformation(activity)
 var allowed by mutableStateOf(false); private set
 var privacyRequired by mutableStateOf(false); private set
 var interstitialReady by mutableStateOf(false); private set
 var status by mutableStateOf(if(AdConfig.enabled) "Checking privacy choices…" else "Advertising is disabled in this release."); private set
 private var loading=false
 private var interstitial: InterstitialAd?=null
 private var enabledByPlayer=true
 private var disposed=false
 private var consentRequestStarted=false
 companion object { private val sdkInitializationStarted=AtomicBoolean(false); private var sdkReady by mutableStateOf(false) }
 fun online(): Boolean {
  val manager=activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
  val capabilities=manager.getNetworkCapabilities(manager.activeNetwork) ?: return false
  return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
 }
 fun launch(playerEnabled: Boolean) {
  enabledByPlayer=playerEnabled
  if(!AdConfig.enabled || !playerEnabled || consentRequestStarted || disposed) return
  consentRequestStarted=true
  val params=ConsentRequestParameters.Builder().build() // No geography overrides in either build.
  consent.requestConsentInfoUpdate(activity,params,{
   if(!disposed) UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { refreshConsent() }
  },{ if(!disposed) { status="Privacy service unavailable. Ads stay optional."; refreshConsent() } })
 }
 private fun refreshConsent() {
  if(disposed) return
  privacyRequired=consent.privacyOptionsRequirementStatus==ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
  allowed=AdConfig.enabled && enabledByPlayer && consent.canRequestAds()
  if(!allowed) { interstitial=null; interstitialReady=false; status="Ads are unavailable with the current privacy choices."; return }
  if(!online()) { status="Offline: puzzles work; ads are unavailable."; return }
  if(sdkReady) { status=if(BuildConfig.DEBUG) "Google test advertising" else "Optional advertising"; return }
  if(sdkInitializationStarted.compareAndSet(false,true)) {
   MobileAds.initialize(activity.applicationContext) {
    sdkReady=true
    activity.runOnUiThread { if(!disposed) status=if(BuildConfig.DEBUG) "Google test advertising" else "Optional advertising" }
   }
  }
 }
 fun setPlayerEnabled(value: Boolean) {
  enabledByPlayer=value
  if(!value) { allowed=false; interstitial=null; interstitialReady=false; status="Advertising is off." }
  else { launch(true); refreshConsent() }
 }
 fun privacyOptions(done: (String?)->Unit) {
  if(!AdConfig.enabled || !privacyRequired) { done("No privacy form is required at this time."); return }
  UserMessagingPlatform.showPrivacyOptionsForm(activity) { error -> refreshConsent(); done(error?.message) }
 }
 fun canLoad()=allowed && enabledByPlayer && consent.canRequestAds() && online() && !disposed && sdkReady
 fun prepareInterstitial() {
  if(!canLoad() || loading || interstitial!=null) return
  loading=true
  InterstitialAd.load(activity,AdConfig.INTERSTITIAL_AD_UNIT_ID,AdRequest.Builder().build(),object: InterstitialAdLoadCallback() {
   override fun onAdLoaded(ad: InterstitialAd) { loading=false; if(canLoad()) { interstitial=ad; interstitialReady=true } }
   override fun onAdFailedToLoad(error: LoadAdError) { loading=false; interstitial=null; interstitialReady=false }
  })
 }
 fun showOptIn(onShown: ()->Unit,onContinue: ()->Unit) {
  val ad=interstitial
  if(!canLoad() || ad==null) { onContinue(); return }
  interstitial=null; interstitialReady=false
  ad.fullScreenContentCallback=object: FullScreenContentCallback() {
   override fun onAdShowedFullScreenContent() { onShown() }
   override fun onAdDismissedFullScreenContent() { onContinue() }
   override fun onAdFailedToShowFullScreenContent(error: AdError) { onContinue() }
  }
  ad.show(activity)
 }
 fun dispose() { disposed=true; interstitial=null; interstitialReady=false }
}
