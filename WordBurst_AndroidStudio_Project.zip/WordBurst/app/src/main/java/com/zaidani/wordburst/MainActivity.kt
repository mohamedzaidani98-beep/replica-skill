package com.zaidani.wordburst
import android.os.Bundle
import android.content.Context
import android.content.res.Configuration
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.zaidani.wordburst.ui.WordBurstApp
class MainActivity: ComponentActivity() {
 override fun attachBaseContext(newBase: Context) {
  val configuration=Configuration(newBase.resources.configuration)
  configuration.setLocale(Locale.ENGLISH)
  configuration.setLayoutDirection(Locale.ENGLISH)
  super.attachBaseContext(newBase.createConfigurationContext(configuration))
 }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { WordBurstApp(this) } }
}
