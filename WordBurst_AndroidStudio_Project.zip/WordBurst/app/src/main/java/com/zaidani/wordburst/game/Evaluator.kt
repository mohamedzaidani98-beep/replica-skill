package com.zaidani.wordburst.game
object Evaluator {
 fun evaluate(answer: String,guess: String): List<Mark> {
  require(answer.length==guess.length && answer.all { it in 'A'..'Z' } && guess.all { it in 'A'..'Z' })
  val marks=MutableList(answer.length) { Mark.ABSENT }; val remaining=mutableMapOf<Char,Int>()
  answer.forEachIndexed { i,c -> if(guess[i]==c) marks[i]=Mark.CORRECT else remaining[c]=(remaining[c] ?: 0)+1 }
  guess.forEachIndexed { i,c -> if(marks[i]!=Mark.CORRECT && (remaining[c] ?: 0)>0) { marks[i]=Mark.PRESENT; remaining[c]=remaining.getValue(c)-1 } }
  return marks
 }
}
data class Submission(val puzzle: Puzzle,val error: String?=null)
class GameRules(private val words: WordBank) {
 fun submit(p: Puzzle): Submission {
  if(p.finished) return Submission(p,"This round is complete.")
  if(p.input.length!=p.length) return Submission(p,"Enter ${p.length} letters.")
  if(p.guesses.any { it.word==p.input }) return Submission(p,"You already tried that word.")
  if(!words.accepts(p.input)) return Submission(p,"That word is not in the offline dictionary.")
  return Submission(p.copy(guesses=p.guesses+Guess(p.input,Evaluator.evaluate(p.answer,p.input)),input=""))
 }
 fun hint(p: Puzzle): Puzzle {
  if(p.finished || p.hintIndex!=null) return p
  val known=(0 until p.length).filter { i -> p.guesses.any { it.marks[i]==Mark.CORRECT } }.toSet()
  return p.copy(hintIndex=(0 until p.length).firstOrNull { it !in known })
 }
}
