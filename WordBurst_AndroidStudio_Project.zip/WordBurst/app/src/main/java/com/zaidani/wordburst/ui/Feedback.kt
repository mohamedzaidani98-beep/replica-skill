package com.zaidani.wordburst.ui
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.View
import android.view.HapticFeedbackConstants
import com.zaidani.wordburst.game.Settings
class Feedback {
 private var tone: ToneGenerator?=null
 fun submit(view: View,settings: Settings,win: Boolean) {
  if(settings.haptics) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
  if(settings.sound) runCatching { if(tone==null) tone=ToneGenerator(AudioManager.STREAM_MUSIC,30); tone?.startTone(if(win) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP,100) }
 }
 fun dispose() { tone?.release(); tone=null }
}
