package com.zaidani.wordburst.data
import com.zaidani.wordburst.game.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.LocalDate
import java.util.UUID
interface SnapshotStore { fun read(): String?; fun write(value: String) }
class GameRepository(private val store: SnapshotStore,val words: WordBank,private val today: ()->LocalDate={LocalDate.now()}) {
 private val json=Json { ignoreUnknownKeys=true; encodeDefaults=true }
 var state: Snapshot=store.read()?.let { json.decodeFromString<Snapshot>(it) } ?: Snapshot(); private set
 val current: Puzzle? get()=if(state.activeId==state.practice?.id) state.practice else state.daily[state.activeId]
 private fun save(s: Snapshot) { store.write(json.encodeToString(s)); state=s }
 fun screen(name: String) { save(state.copy(screen=name)) }
 fun settings(settings: Settings) { save(state.copy(settings=settings)) }
 fun start(mode: Mode,length: Int,difficulty: Difficulty=Difficulty.STANDARD) {
  require(length in 4..6)
  val date=today(); val key="daily-v1:$date:$length"
  val p=if(mode==Mode.DAILY) state.daily[key] ?: Puzzle(key,mode,length,Difficulty.STANDARD,words.daily(date,length),date.toString()) else Puzzle(UUID.randomUUID().toString(),mode,length,difficulty,words.practice(length,difficulty,state.recent),date.toString())
  save(if(mode==Mode.DAILY) state.copy(daily=state.daily+(key to p),activeId=p.id,screen="game") else state.copy(practice=p,activeId=p.id,screen="game",recent=(state.recent+p.answer).takeLast(36)))
 }
 fun resumePractice(): Boolean { val p=state.practice ?: return false; save(state.copy(activeId=p.id,screen="game")); return true }
 fun rollover(): Boolean {
  val p=current ?: return false
  if(p.mode==Mode.DAILY && p.date!=today().toString()) { start(Mode.DAILY,p.length); return true }; return false
 }
 private fun update(p: Puzzle) {
  val newRecord=p.finished && state.records.none { it.id==p.id }
  val s=if(p.mode==Mode.PRACTICE) state.copy(practice=p) else state.copy(daily=state.daily+(p.id to p))
  save(s.copy(records=if(newRecord) s.records+RoundRecord(p.id,p.mode,p.date,p.length,p.won,p.guesses.size,p.hintIndex!=null) else s.records,practiceCompletions=s.practiceCompletions+if(newRecord && p.mode==Mode.PRACTICE) 1 else 0))
 }
 fun key(key: String) {
  if(rollover()) return
  val p=current ?: return; if(p.finished) return
  when(key) { "⌫" -> update(p.copy(input=p.input.dropLast(1))); else -> if(key.length==1 && key[0] in 'A'..'Z' && p.input.length<p.length) update(p.copy(input=p.input+key)) }
 }
 fun submit(): String? {
  if(rollover()) return "A new local day has started. Here is today's puzzle."
  val p=current ?: return null; val result=GameRules(words).submit(p)
  if(result.error==null) update(result.puzzle)
  return result.error
 }
 fun hint() { if(!rollover()) current?.let { update(GameRules(words).hint(it)) } }
 fun markAdShown(now: Long) { save(state.copy(lastAdRound=state.practiceCompletions,lastAdTime=now)) }
}
