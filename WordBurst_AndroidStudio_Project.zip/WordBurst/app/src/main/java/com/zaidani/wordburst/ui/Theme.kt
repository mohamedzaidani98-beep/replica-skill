package com.zaidani.wordburst.ui
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.zaidani.wordburst.game.Settings
object Brand {
 val Blue=Color(0xFF1677F2); val Red=Color(0xFFF04452); val Green=Color(0xFF2EC96C); val Yellow=Color(0xFFFFD33D)
 val Ink=Color(0xFF17284A); val White=Color.White; val Background=Color(0xFFF4F8FF)
 val Error=Color(0xFFA11532)
}
@Composable fun WordBurstTheme(settings: Settings,content: @Composable ()->Unit) {
 val dark=settings.theme=="dark" || (settings.theme=="system" && isSystemInDarkTheme())
 val scheme=if(dark) darkColorScheme(primary=Brand.Yellow,onPrimary=Brand.Ink,background=Brand.Ink,surface=Color(0xFF22385C),onBackground=Brand.White,onSurface=Brand.White,outline=Color(0xFFC1D1EC),error=Color(0xFFFFBBC4)) else lightColorScheme(primary=Brand.Ink,onPrimary=Brand.White,secondary=Brand.Blue,background=Brand.Background,surface=Brand.White,onBackground=Brand.Ink,onSurface=Brand.Ink,outline=Color(0xFF62738E),error=Brand.Error)
 MaterialTheme(colorScheme=scheme,content=content)
}
