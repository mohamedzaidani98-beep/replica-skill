package com.zaidani.wordburst.game
import java.security.MessageDigest
import java.nio.ByteBuffer
import java.time.LocalDate
import kotlin.random.Random
class WordBank(val answers: Map<Int,List<String>>,private val accepted: Set<String>) {
 init { require((4..6).all { n -> (answers[n]?.size ?: 0)>=100 }); require(answers.values.flatten().all { it in accepted }) }
 fun accepts(word: String)=word in accepted
 fun daily(date: LocalDate,length: Int): String {
  val pool=answers.getValue(length)
  val digest=MessageDigest.getInstance("SHA-256").digest("WordBurst/daily/v1/$date/$length".toByteArray(Charsets.UTF_8))
  val index=(ByteBuffer.wrap(digest).long and Long.MAX_VALUE)%pool.size
  return pool[index.toInt()]
 }
 fun practice(length: Int,difficulty: Difficulty,recent: List<String>,random: Random=Random.Default): String {
  val all=answers.getValue(length)
  val pool=when(difficulty) { Difficulty.RELAXED -> all.take(100); Difficulty.STANDARD -> all; Difficulty.TRICKY -> all.filter { it.toSet().size<it.length }.ifEmpty { all.takeLast(100) } }
  return pool.filter { it !in recent.takeLast(12) }.ifEmpty { pool.filter { it!=recent.lastOrNull() } }.ifEmpty { pool }.random(random)
 }
}
object Stats {
 fun streak(records: List<RoundRecord>,today: LocalDate): Int {
  val wins=records.filter { it.mode==Mode.DAILY && it.won }.map { LocalDate.parse(it.date) }.toSet()
  var date=if(today in wins) today else today.minusDays(1); var count=0
  while(date in wins) { count++; date=date.minusDays(1) }
  return count
 }
 fun share(p: Puzzle): String {
  val label=if(p.mode==Mode.DAILY) "Daily ${p.date}" else "Practice"
  val progress=if(p.finished) { if(p.won) "${p.guesses.size}/6" else "X/6" } else "${p.guesses.size}/6 in progress"
  return "WordBurst • $label • ${p.length} letters • $progress${if(p.hintIndex!=null) " • hint used" else ""}\n"+p.guesses.joinToString("\n") { g -> g.marks.joinToString("") { when(it) { Mark.CORRECT -> "🟩"; Mark.PRESENT -> "🟨"; Mark.ABSENT -> "⬜" } } }
 }
}
object AdPolicy {
 fun eligible(s: Snapshot,p: Puzzle?,now: Long) = p?.mode==Mode.PRACTICE && p.finished && s.practiceCompletions-s.lastAdRound>=3 && now-s.lastAdTime>=300_000L
}
