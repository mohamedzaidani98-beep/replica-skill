package com.zaidani.wordburst.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zaidani.wordburst.ads.*
import com.zaidani.wordburst.game.*
import java.time.LocalDate
@Composable fun BrandHeader() {
 Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.clearAndSetSemantics { contentDescription="WordBurst" }) {
  Row(Modifier.background(Brush.linearGradient(listOf(Brand.Blue,Brand.Ink)),RoundedCornerShape(18.dp)).padding(8.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
   listOf("W" to Brand.Yellow,"B" to Brand.White).forEach { (letter,color) -> Box(Modifier.background(color,RoundedCornerShape(8.dp)).padding(horizontal=7.dp,vertical=4.dp)) { Text(letter,color=Brand.Ink,fontSize=26.sp,fontWeight=FontWeight.Black) } }
  }
  Column { Text("Word",fontSize=28.sp,fontWeight=FontWeight.Black); Text("Burst",fontSize=28.sp,fontWeight=FontWeight.Black) }
 }
}
@Composable fun ModePicker(length: Int,difficulty: Difficulty,onLength: (Int)->Unit,onDifficulty: (Difficulty)->Unit) {
 Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
  Text("Choose your word",fontWeight=FontWeight.Bold)
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) { (4..6).forEach { n -> FilterChip(selected=length==n,onClick={onLength(n)},label={Text("$n letters")},modifier=Modifier.weight(1f)) } }
  Text("Practice difficulty",style=MaterialTheme.typography.labelLarge)
  Difficulty.entries.forEach { d -> Row(verticalAlignment=Alignment.CenterVertically) {
   RadioButton(selected=difficulty==d,onClick={onDifficulty(d)},modifier=Modifier.semantics { contentDescription=d.name.lowercase().replaceFirstChar { it.uppercase() }+" difficulty" })
   Column { Text(d.name.lowercase().replaceFirstChar { it.uppercase() }); Text(when(d) { Difficulty.RELAXED->"Everyday favorites"; Difficulty.STANDARD->"The full common-word pool"; Difficulty.TRICKY->"Words with repeated letters" },style=MaterialTheme.typography.labelMedium) }
  } }
 } }
}
@Composable fun Tutorial() {
 Text("Every letter has a clue",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
 Text("Find the hidden English word in six attempts. Choose 4, 5 or 6 letters on the menu. Type with the on-screen keyboard or a connected keyboard.")
 val example=Puzzle("tutorial",Mode.PRACTICE,5,Difficulty.STANDARD,"APPLE","",listOf(Guess("ALLEY",Evaluator.evaluate("APPLE","ALLEY"))))
 ClueGrid(example,false)
 Text("Example answer: APPLE. Guess: ALLEY. A is in the right place (✓). Only one L can match the answer: the first L is elsewhere (↔), the second is unmatched (×). E is elsewhere; Y is unmatched.")
 Text("A key remembers its strongest clue. A later unmatched copy never erases an earlier correct or present match. Symbols and spoken labels accompany every clue.")
 Text("One optional hint reveals a position without changing your guesses or attempts. A hint is marked on your result. Hints are never tied to ads.")
 Text("Daily Challenge is one saved puzzle per local date and word length. A new date opens a fresh puzzle. Practice has no daily limit. Leaving the screen saves every letter.")
}
@Composable fun Statistics(state: Snapshot,today: LocalDate) {
 val records=state.records
 Text("Your bright spots",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
 val wins=records.count { it.won }
 Text("${records.size} completed · $wins solved · ${if(records.isEmpty()) 0 else wins*100/records.size}% success",style=MaterialTheme.typography.titleMedium)
 Text("Daily streak: ${Stats.streak(records,today)} days")
 Text("A daily win in any length counts once per local date. Your streak can continue if you won yesterday and have not played today yet.")
 Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
  Text("Solved in…",fontWeight=FontWeight.Bold)
  (1..6).forEach { n -> Text("$n ${if(n==1) "guess" else "guesses"}: ${records.count { it.won && it.attempts==n }}") }
 } }
 Text("Practice rounds: ${records.count { it.mode==Mode.PRACTICE }} · Daily rounds: ${records.count { it.mode==Mode.DAILY }}")
 Text("Hints used: ${records.count { it.hinted }}")
}
@Composable fun SettingsScreen(settings: Settings,ads: AdsCoordinator,onSettings: (Settings)->Unit,onPrivacy: ()->Unit) {
 Text("Make it yours",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
 SettingSwitch("Sound",settings.sound) { onSettings(settings.copy(sound=it)) }
 SettingSwitch("Haptic feedback",settings.haptics) { onSettings(settings.copy(haptics=it)) }
 SettingSwitch("Strong tile outlines",settings.contrast) { onSettings(settings.copy(contrast=it)) }
 Text("Theme",fontWeight=FontWeight.Bold)
 listOf("system","light","dark").forEach { value -> Row(verticalAlignment=Alignment.CenterVertically) { RadioButton(selected=settings.theme==value,onClick={onSettings(settings.copy(theme=value))},modifier=Modifier.semantics { contentDescription="$value theme" }); Text(value.replaceFirstChar { it.uppercase() }) } }
 Text("Privacy & advertising",style=MaterialTheme.typography.titleLarge)
 SettingSwitch("Optional ads",settings.ads) { onSettings(settings.copy(ads=it)) }
 Text(ads.status,style=MaterialTheme.typography.bodySmall)
 OutlinedButton(onClick=onPrivacy,enabled=ads.privacyRequired) { Text("Privacy Options") }
 Text("Your puzzles and statistics stay on this device. Core play works offline. The Google advertising and consent SDKs may process network, device and interaction data when advertising is enabled. This build does not request an advertising identifier. Turn optional ads off to stop future ad requests. Privacy Options is active when Google's consent service requires it.")
 HorizontalDivider()
 Text("Word resources",fontWeight=FontWeight.Bold)
 Text("English accepted guesses: Wordnik wordlist (MIT, © 2020 Wordnik). Common answers selected for WordBurst. Full license: Wordnik permits use, copying, modification, merging, publication, distribution, sublicensing and sale when its copyright and permission notice are included. Provided without warranty; authors are not liable for claims or damages. The complete notice is included in the project and application assets.")
 Text("System text size is supported. Letter feedback includes ✓, ↔ and × symbols as well as colors. No account, camera, location, contacts or storage access is required.")
}
@Composable private fun SettingSwitch(label: String,checked: Boolean,onChecked: (Boolean)->Unit) {
 Row(Modifier.fillMaxWidth().heightIn(min=52.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) { Text(label,modifier=Modifier.weight(1f)); Switch(checked=checked,onCheckedChange=onChecked,modifier=Modifier.semantics { contentDescription=label }) }
}
