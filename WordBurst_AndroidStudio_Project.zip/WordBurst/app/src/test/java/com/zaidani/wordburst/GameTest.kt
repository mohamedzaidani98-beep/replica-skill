package com.zaidani.wordburst
import com.zaidani.wordburst.game.*
import com.zaidani.wordburst.data.*
import org.junit.Test
import org.junit.Assert.*
import java.io.File
import java.time.LocalDate
import kotlin.random.Random
class MemoryStore: SnapshotStore {
 var value: String?=null
 var failed=false
 override fun read()=value
 override fun write(value: String) { check(!failed); this.value=value }
}
class GameTest {
 private fun bank(): WordBank {
  val root=File(requireNotNull(System.getProperty("wordburst.assets")))
  return WordBank((4..6).associateWith { File(root,"answers_$it.txt").readLines() },File(root,"accepted.txt").readLines().toSet())
 }
 private fun puzzle(answer: String="APPLE",input: String="")=Puzzle("test",Mode.PRACTICE,answer.length,Difficulty.STANDARD,answer,"2026-10-23",input=input)
 private val C=Mark.CORRECT; private val P=Mark.PRESENT; private val A=Mark.ABSENT
 @Test fun exactMatch() { assertEquals(List(5) { C },Evaluator.evaluate("APPLE","APPLE")) }
 @Test fun duplicateGuessConsumesOnlyAvailableCopies() { assertEquals(listOf(C,P,A,P,A),Evaluator.evaluate("APPLE","ALLEY")) }
 @Test fun exactMatchesReservedBeforePresentMatches() { assertEquals(listOf(P,C,A,A,A),Evaluator.evaluate("LEVEL","EERIE")) }
 @Test fun multipleDuplicateAnswerLetters() { assertEquals(listOf(P,P,P,P,P,A),Evaluator.evaluate("BANANA","ANANAS")) }
 @Test fun matchingSuffixAndAbsentPrefix() { assertEquals(listOf(A,A,A,C,C),Evaluator.evaluate("GEESE","THOSE")) }
 @Test fun evaluatorRejectsWrongLength() { assertThrows(IllegalArgumentException::class.java) { Evaluator.evaluate("APPLE","APPLEZ") } }
 @Test fun evaluatorRejectsNonLetters() { assertThrows(IllegalArgumentException::class.java) { Evaluator.evaluate("APPLE","12345") } }
 @Test fun shortGuessDoesNotConsumeAttempt() { val p=puzzle(input="APP"); val r=GameRules(bank()).submit(p); assertEquals(p,r.puzzle); assertNotNull(r.error) }
 @Test fun invalidDictionaryGuessDoesNotConsumeAttempt() { val r=GameRules(bank()).submit(puzzle(input="ZZZZZ")); assertNotNull(r.error); assertEquals(0,r.puzzle.guesses.size) }
 @Test fun repeatedGuessDoesNotConsumeAttempt() { val rules=GameRules(bank()); val p=rules.submit(puzzle(input="ALLEY")).puzzle; val r=rules.submit(p.copy(input="ALLEY")); assertNotNull(r.error); assertEquals(1,r.puzzle.guesses.size) }
 @Test fun winStopsFurtherGuesses() { val rules=GameRules(bank()); val p=rules.submit(puzzle(input="APPLE")).puzzle; assertTrue(p.won); assertTrue(p.finished); assertNotNull(rules.submit(p.copy(input="ALLEY")).error) }
 @Test fun sixthMissLoses() { val words=bank(); val rules=GameRules(words); var p=puzzle(); words.answers.getValue(5).filter { it!="APPLE" }.take(6).forEach { p=rules.submit(p.copy(input=it)).puzzle }; assertTrue(p.finished); assertFalse(p.won); assertEquals(6,p.guesses.size) }
 @Test fun strongestKeyboardClueIsNotDowngraded() { val p=puzzle().copy(guesses=listOf(Guess("ALLEY",Evaluator.evaluate("APPLE","ALLEY")),Guess("BRAVE",Evaluator.evaluate("APPLE","BRAVE")))); assertEquals(C,p.keyboard['A']); assertEquals(P,p.keyboard['L']); assertEquals(C,p.keyboard['E']) }
 @Test fun hintKeepsSolutionPossibleAndDoesNotConsumeAttempt() { val rules=GameRules(bank()); val p=rules.hint(puzzle()); assertNotNull(p.hintIndex); assertEquals(0,p.guesses.size); assertTrue(rules.submit(p.copy(input=p.answer)).puzzle.won); assertEquals(p,rules.hint(p)) }
 @Test fun hintDoesNotSpoilAlreadyCompletedGame() { val p=GameRules(bank()).submit(puzzle(input="APPLE")).puzzle; assertEquals(p,GameRules(bank()).hint(p)) }
 @Test fun dailyIsStableAcrossInstances() { val day=LocalDate.parse("2026-10-23"); for(n in 4..6) assertEquals(bank().daily(day,n),bank().daily(day,n)) }
 @Test fun dailyAlwaysUsesRightLengthAndValidAnswer() { for(n in 4..6) { val word=bank().daily(LocalDate.parse("2026-10-23"),n); assertEquals(n,word.length); assertTrue(bank().accepts(word)) } }
 @Test fun practiceAvoidsImmediateRepeat() { val words=bank(); for(n in 4..6) for(d in Difficulty.entries) { val first=words.practice(n,d,emptyList(),Random(10)); assertNotEquals(first,words.practice(n,d,listOf(first),Random(10))) } }
 @Test fun fullCorpusIsAdequate() { val words=bank(); for(n in 4..6) { assertTrue(words.answers.getValue(n).size>500); assertTrue(words.answers.getValue(n).all { it.length==n && words.accepts(it) }) } }
 @Test fun typedInputSurvivesRecreation() { val store=MemoryStore(); val words=bank(); val repo=GameRepository(store,words); repo.start(Mode.PRACTICE,5); repo.key("A"); repo.key("B"); val recreated=GameRepository(store,words); assertEquals("AB",recreated.current!!.input); assertEquals(repo.current,recreated.current); assertEquals("game",recreated.state.screen) }
 @Test fun dailyCannotBeResetByStartingAgain() { val store=MemoryStore(); val repo=GameRepository(store,bank()) { LocalDate.parse("2026-10-23") }; repo.start(Mode.DAILY,5); "ALLEY".forEach { repo.key(it.toString()) }; repo.submit(); val p=repo.current; repo.start(Mode.DAILY,5); assertEquals(p,repo.current); assertEquals(1,repo.current!!.guesses.size) }
 @Test fun midnightOpensNewRecordAndPreservesOld() { var date=LocalDate.parse("2026-10-23"); val repo=GameRepository(MemoryStore(),bank()) { date }; repo.start(Mode.DAILY,5); repo.key("A"); val old=repo.current!!; date=date.plusDays(1); assertTrue(repo.rollover()); assertNotEquals(old.id,repo.current!!.id); assertEquals(old,repo.state.daily[old.id]); assertEquals("",repo.current!!.input) }
 @Test fun previousDateStillHasItsOriginalProgress() { var date=LocalDate.parse("2026-10-23"); val repo=GameRepository(MemoryStore(),bank()) { date }; repo.start(Mode.DAILY,4); repo.key("A"); val original=repo.current; date=date.plusDays(1); repo.rollover(); date=date.minusDays(1); repo.rollover(); assertEquals(original,repo.current) }
 @Test fun finishedDailyPersistsAndStatsAreNotDuplicated() { val store=MemoryStore(); val words=bank(); val repo=GameRepository(store,words); repo.start(Mode.DAILY,5); repo.current!!.answer.forEach { repo.key(it.toString()) }; assertNull(repo.submit()); assertEquals(1,repo.state.records.size); repo.start(Mode.DAILY,5); repo.submit(); assertEquals(1,repo.state.records.size); assertTrue(GameRepository(store,words).current!!.won) }
 @Test fun settingsSurviveRecreation() { val store=MemoryStore(); val words=bank(); val repo=GameRepository(store,words); val settings=Settings(sound=true,haptics=false,theme="dark",contrast=true,ads=false); repo.settings(settings); assertEquals(settings,GameRepository(store,words).state.settings) }
 @Test fun persistenceFailureDoesNotCommitInMemory() { val store=MemoryStore(); val repo=GameRepository(store,bank()); repo.start(Mode.PRACTICE,4); val before=repo.state; store.failed=true; assertThrows(IllegalStateException::class.java) { repo.key("A") }; assertEquals(before,repo.state) }
 @Test fun unfinishedShareNeverLeaksWord() { val p=puzzle().copy(hintIndex=0); val share=Stats.share(p); assertFalse(share.contains("APPLE")); assertTrue(share.contains("in progress")); assertTrue(share.contains("hint used")) }
 @Test fun completeShareHasCluesWithoutAnswer() { val p=GameRules(bank()).submit(puzzle(input="APPLE")).puzzle; val share=Stats.share(p); assertFalse(share.contains("APPLE")); assertTrue(share.contains("1/6")); assertTrue(share.contains("🟩")) }
 @Test fun dailyStreakCountsDatesNotLengths() { val today=LocalDate.parse("2026-10-23"); val records=listOf(RoundRecord("1",Mode.DAILY,today.toString(),4,true,2,false),RoundRecord("2",Mode.DAILY,today.toString(),5,true,3,false),RoundRecord("3",Mode.DAILY,today.minusDays(1).toString(),4,true,1,false)); assertEquals(2,Stats.streak(records,today)); assertEquals(2,Stats.streak(records,today.plusDays(1))); assertEquals(0,Stats.streak(records,today.plusDays(2))) }
 @Test fun adsRequireThreeRoundsAndFiveMinutesAndPracticeResult() { val p=puzzle().copy(guesses=listOf(Guess("APPLE",List(5) { C }))); val s=Snapshot(practiceCompletions=3,lastAdTime=0); assertTrue(AdPolicy.eligible(s,p,300_000)); assertFalse(AdPolicy.eligible(s.copy(practiceCompletions=2),p,300_000)); assertFalse(AdPolicy.eligible(s,p,299_999)); assertFalse(AdPolicy.eligible(s,p.copy(mode=Mode.DAILY),300_000)); assertFalse(AdPolicy.eligible(s,puzzle(),300_000)); assertFalse(AdPolicy.eligible(s.copy(lastAdRound=3),p,600_000)) }
 @Test fun adFrequencyCapsPersistAcrossRecreation() { val store=MemoryStore(); val words=bank(); val repo=GameRepository(store,words); repo.markAdShown(500_000); assertEquals(500_000,GameRepository(store,words).state.lastAdTime) }
 @Test fun dailyV1VectorsAreFrozen() { val words=bank(); val day=LocalDate.parse("2026-10-23"); assertEquals("BITE",words.daily(day,4)); assertEquals("UNCLE",words.daily(day,5)); assertEquals("RITUAL",words.daily(day,6)) }

}
