package com.zaidani.wordburst
import androidx.test.runner.AndroidJUnitRunner
import com.zaidani.wordburst.data.*
import com.zaidani.wordburst.game.Settings
/** Initialize deterministic, ads-off test data before any Activity rule launches. */
class WordBurstTestRunner: AndroidJUnitRunner() {
 override fun onStart() {
  val context=targetContext
  context.getSharedPreferences("wordburst_state_v1",0).edit().clear().commit()
  GameRepository(AndroidStore(context),loadWords(context.assets)).settings(Settings(ads=false))
  super.onStart()
 }
}
