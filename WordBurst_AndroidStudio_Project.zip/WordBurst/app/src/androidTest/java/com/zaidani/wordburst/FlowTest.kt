package com.zaidani.wordburst
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Rule
import org.junit.Test
import com.zaidani.wordburst.data.*
import com.zaidani.wordburst.game.*
import org.junit.Assert.*
class FlowTest {
 @get:Rule val ui=createAndroidComposeRule<MainActivity>()
 @Test fun menuStartsPracticeAndRestoresTypedInput() {
  // Host test starts from a clean application data state; disable ads for deterministic device QA.
  ui.runOnUiThread {
   val context=ui.activity
   val repo=GameRepository(AndroidStore(context),loadWords(context.assets))
   repo.settings(repo.state.settings.copy(ads=false)); repo.screen("menu")
  }
  ui.activityRule.scenario.recreate()
  ui.onNodeWithText("Play",useUnmergedTree=true).performScrollTo().performClick()
  if(ui.onAllNodesWithText("Start new").fetchSemanticsNodes().isNotEmpty()) ui.onNodeWithText("Start new").performClick()
  ui.onNodeWithTag("clue-grid").assertExists()
  ui.onNodeWithContentDescription("A, not tried").performScrollTo().performClick()
  ui.activityRule.scenario.recreate()
  ui.onNodeWithContentDescription("Attempt 1, letter 1: A").assertExists()
  ui.onNodeWithText("Save & leave").performScrollTo().performClick()
  ui.onNodeWithText("Resume practice").performScrollTo().assertExists()
 }
 @Test fun persistentRepositoryRoundTrip() {
  val context=InstrumentationRegistry.getInstrumentation().targetContext
  val words=loadWords(context.assets)
  val repo=GameRepository(AndroidStore(context),words)
  repo.start(Mode.PRACTICE,6); repo.key("A")
  assertEquals(repo.current,GameRepository(AndroidStore(context),words).current)
 }
}
