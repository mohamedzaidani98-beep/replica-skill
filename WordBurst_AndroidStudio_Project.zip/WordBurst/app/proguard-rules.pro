# Google Mobile Ads, UMP and serialization ship consumer rules.
# Keep source information for crash traces; upload the release mapping file to Play.
-keepattributes SourceFile,LineNumberTable
