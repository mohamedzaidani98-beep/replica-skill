plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose"); id("org.jetbrains.kotlin.plugin.serialization") }
fun quoted(value: String)=34.toChar().toString()+value+34.toChar()
val prodAppId=providers.gradleProperty("ADMOB_APP_ID").orElse("")
val prodBanner=providers.gradleProperty("BANNER_AD_UNIT_ID").orElse("")
val prodInterstitial=providers.gradleProperty("INTERSTITIAL_AD_UNIT_ID").orElse("")
val productionAds=providers.gradleProperty("ENABLE_PRODUCTION_ADS").orElse("false").get()=="true"
val allProductionIds=listOf(prodAppId.get(),prodBanner.get(),prodInterstitial.get())
val productionFormatsValid=Regex("ca-app-pub-[0-9]{16}~[0-9]{10}").matches(prodAppId.get()) && listOf(prodBanner.get(),prodInterstitial.get()).all { Regex("ca-app-pub-[0-9]{16}/[0-9]{10}").matches(it) }
if(productionAds && (!productionFormatsValid || allProductionIds.any { it.contains("3940256099942544") })) error("Production ads require your own three valid IDs; Google sample IDs cannot monetize release.")
android {
 namespace="com.zaidani.wordburst"
 compileSdk=36
 buildToolsVersion="36.0.0"
 defaultConfig { applicationId="com.zaidani.wordburst"; minSdk=24; targetSdk=36; versionCode=1; versionName="1.0.0"; testInstrumentationRunner="com.zaidani.wordburst.WordBurstTestRunner" }
 buildFeatures { compose=true; buildConfig=true }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17; isCoreLibraryDesugaringEnabled=true }
 testOptions { unitTests.all { it.systemProperty("wordburst.assets",file("src/main/assets/words").absolutePath) } }
 buildTypes {
  debug {
   buildConfigField("boolean","ADS_ENABLED","true")
   buildConfigField("String","ADMOB_APP_ID",quoted("ca-app-pub-3940256099942544~3347511713"))
   buildConfigField("String","BANNER_AD_UNIT_ID",quoted("ca-app-pub-3940256099942544/6300978111"))
   buildConfigField("String","INTERSTITIAL_AD_UNIT_ID",quoted("ca-app-pub-3940256099942544/1033173712"))
   manifestPlaceholders["admobAppId"]="ca-app-pub-3940256099942544~3347511713"
  }
  release {
   isMinifyEnabled=true; isShrinkResources=true
   proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro")
   buildConfigField("boolean","ADS_ENABLED",productionAds.toString())
   buildConfigField("String","ADMOB_APP_ID",quoted(if(productionAds) prodAppId.get() else ""))
   buildConfigField("String","BANNER_AD_UNIT_ID",quoted(if(productionAds) prodBanner.get() else ""))
   buildConfigField("String","INTERSTITIAL_AD_UNIT_ID",quoted(if(productionAds) prodInterstitial.get() else ""))
   // Valid public sample metadata is inert when release ADS_ENABLED=false; no initialization or requests.
   manifestPlaceholders["admobAppId"]=if(productionAds) prodAppId.get() else "ca-app-pub-3940256099942544~3347511713"
  }
 }
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }
dependencies {
 coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
 implementation(platform("androidx.compose:compose-bom:2025.12.01"))
 implementation("androidx.activity:activity-compose:1.11.0")
 implementation("androidx.lifecycle:lifecycle-runtime-compose:2.9.4")
 implementation("androidx.compose.material3:material3")
 implementation("androidx.compose.ui:ui-tooling-preview")
 implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
 implementation("com.google.android.gms:play-services-ads:25.5.0")
 implementation("com.google.android.ump:user-messaging-platform:4.0.0")
 debugImplementation("androidx.compose.ui:ui-tooling")
 testImplementation("junit:junit:4.13.2")
 androidTestImplementation(platform("androidx.compose:compose-bom:2025.12.01"))
 androidTestImplementation("androidx.compose.ui:ui-test-junit4")
 androidTestImplementation("androidx.test.ext:junit:1.3.0")
 androidTestImplementation("androidx.test:runner:1.7.0")
 debugImplementation("androidx.compose.ui:ui-test-manifest")
}
