# Google test advertising and UMP

Versions verified from official Google Maven metadata on 2026-10-23: Google Mobile Ads 25.5.0; User Messaging Platform 4.0.0. Code follows the official Android interfaces and accessible Google sample source. The developers.google.com pages returned HTTP 403 in this cloud instance; the links below remain the authoritative implementation/policy references for your review.

## Configuration
One configuration location: **app/build.gradle.kts** defines `ADMOB_APP_ID`, `BANNER_AD_UNIT_ID`, `INTERSTITIAL_AD_UNIT_ID` and `ADS_ENABLED` for each variant. Runtime access is centralized in ads/AdsCoordinator.kt, object AdConfig. Manifest metadata `com.google.android.gms.ads.APPLICATION_ID` uses `${admobAppId}`. Debug is fixed to Google's public Android test app `ca-app-pub-3940256099942544~3347511713`, banner `/6300978111`, interstitial `/1033173712`; it never reads production IDs.

Default release has ADS_ENABLED=false and empty runtime unit IDs. A valid public sample app ID remains only as inert manifest metadata to satisfy the bundled SDK provider's startup check. No release ad or consent requests are initiated by application code when disabled; this is not a claim that the SDK binary is absent or all internal SDK behavior was measured. Do not call it production monetization.

To opt into production release ads, put your own non-secret IDs in a private local/user Gradle configuration (not signing passwords):

```
ENABLE_PRODUCTION_ADS=true
ADMOB_APP_ID=your-app-id
BANNER_AD_UNIT_ID=your-banner-unit-id
INTERSTITIAL_AD_UNIT_ID=your-interstitial-unit-id
```

The build rejects the Google sample publisher ID when production ads are enabled and requires correct ID formats. The default build works without these properties. Unit IDs are account identifiers, not API keys. Never use live IDs for debug. Do not add geography overrides to release; none exist in this project.

## Consent, placement and caps
With advertising enabled, launch calls UMP requestConsentInfoUpdate, then loadAndShowConsentFormIfRequired, and checks canRequestAds before initialization or loading. An atomic initialization gate, per-banner composition lifecycle and an in-flight interstitial guard prevent duplicate initialization/requests. Consent errors do not block play; absence of usable consent prevents requests. Previous valid consent may permit requests as documented by UMP. The player switch can stop all future application ad requests. Settings surfaces Privacy Options when UMP reports REQUIRED and refreshes eligibility after the form closes. Connectivity validation is checked before ad loading.

The only banner is a labelled separated region on the **main menu**, with fixed reserved height. No banner appears during a puzzle, tutorial or keyboard use. Interstitials can be offered only on completed **practice** result screens, after three newly completed practice rounds since the last shown ad and at least five minutes since it. Both counters persist across process death. A separate explicit optional-ad button initiates display, while the ordinary Next button always continues without advertising. Show failure, offline state, absent consent or missing loaded ad simply continues play. Ads never appear on launch, back, a guess, tutorial or daily puzzles. No rewarded ads or gated hints.

## Console setup and policy testing
Create an AdMob Android app with the fixed package; create your banner/interstitial units. In AdMob Privacy & messaging, configure applicable European regulations, US-state and other consent messages, publish them, and supply a valid privacy-policy URL. Test UMP in appropriate regions/on registered test devices using debug-only overrides if you choose to add them; do not infer successful consent from compilation. Verify an actual Google test-ad label before any interaction. Never click production ads during development.

Advertising identifier and AdServices ID/topics/attribution permissions are explicitly removed from the merged manifest; review actual SDK behavior and whether this contextual configuration fits your consent and monetization choices. INTERNET and ACCESS_NETWORK_STATE remain for advertising/consent; the SDK’s AndroidX WorkManager also merges WAKE_LOCK and FOREGROUND_SERVICE. No gameplay foreground service is started. SDKs can still process other data; see DATA_SAFETY.md. App-level optional-ad controls are not a substitute for required consent or legal compliance.

Official references:
- https://developers.google.com/admob/android/quick-start
- https://developers.google.com/admob/android/privacy
- https://developers.google.com/admob/android/privacy/options
- https://developers.google.com/admob/android/test-ads
- https://developers.google.com/admob/android/banner
- https://developers.google.com/admob/android/interstitial
- https://github.com/googleads/googleads-mobile-android-examples

Device/network checks are NOT TESTED here. Consent, actual test ad serving, Privacy Options, rotation while a form is open, offline/failure fall-through and callback races must be validated before publication.
