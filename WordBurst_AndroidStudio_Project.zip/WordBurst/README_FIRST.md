# WordBurst — start here

**Guess the word. Feel the burst.** A native English word-deduction game with offline 4/5/6-letter practice and daily puzzles. Application ID and namespace: `com.zaidani.wordburst`. Version 1 / 1.0.0. Activity resource configuration is fixed to English; platform share sheets and SDK-owned web content remain controlled by their providers. Minimum Android 7.0 (API 24); compile and target API 36.

## Android Studio
1. Extract WordBurst_AndroidStudio_Project.zip. Open the **WordBurst** folder containing settings.gradle.kts, gradlew and app/.
2. Use Android Studio supporting AGP 8.13.2, with a complete JDK 17 or 21 selected as the Gradle JDK (a JRE alone is insufficient).
3. Install Android SDK platform 36 and build tools 36.0.0 in SDK Manager; accept the SDK licenses. Let Gradle sync complete. Android Studio creates your own local.properties SDK path; it is intentionally absent from this ZIP.
4. Connect an Android 7+ phone by USB, enable Developer options > USB debugging, approve your computer, select the device and press **Run**. Core puzzles work in airplane mode. Ads/consent need network access and are optional.
5. Test the full checklist in QA_REPORT.md before publishing. On Windows use gradlew.bat instead of ./gradlew.

```sh
./gradlew testDebugUnitTest
./gradlew assembleDebug
./gradlew lintDebug
./gradlew bundleRelease
./gradlew assembleDebugAndroidTest
./gradlew connectedDebugAndroidTest
```

Debug APK: app/build/outputs/apk/debug/app-debug.apk. Release AAB: app/build/outputs/bundle/release/app-release.aab. Android tests require a phone/emulator. Full build: `./gradlew build`.

## Play and resume
Choose word length and practice difficulty, or open a local-date Daily Challenge. Type a real English word on the custom keyboard or a hardware keyboard. Six attempts; duplicate letters use frequency-aware matching. ✓ means correct place, ↔ means elsewhere, × means unmatched. Keyboard clues never downgrade. One optional free hint reveals a position and is marked on the result. No attempt or progress is gated by ads. Save & leave or Android Back returns to the menu; every typed letter is already stored. Process recreation and rotation restore the active route and puzzle. Practice offers a new-round confirmation if one is unfinished.

Daily results are saved separately for each date and word length. Midnight/foreground/input checks open the new day's board, preserving the previous record. Local clock/time-zone changes change the current local date; no server validation is claimed. Sharing never includes the answer, even for an unfinished round. Stats include all completed rounds and a daily win streak by calendar date. Tricky difficulty selects repeated-letter answers; Relaxed uses 100 everyday selections; all modes retain six attempts.

## Brand and artwork
Brand colors and theme: ui/Theme.kt. Logo/header: ui/MenuScreens.kt. The images were visible in the request but no PNG binaries were made available to this workspace. This build therefore contains an original hand-authored W/B vector fallback with adaptive safe-zone foreground, blue background and Android 13 monochrome icon. **The three supplied PNG binaries are not included or represented as originals.** See ASSETS.md for exact replacement locations. Launcher name: res/values/strings.xml. Fixed app package should be chosen before first Play upload.

## Ads and privacy
Debug uses official Google test IDs only. Default release ads are OFF; the SDK remains bundled and its manifest providers exist, but application ad/consent requests are gated off. Settings has a persistent ads-off control, sound/haptic toggles, strong outlines and system/light/dark theme. See ADS_AND_CONSENT.md for consent and production setup and DATA_SAFETY.md for truthful privacy guidance. No keystore, password, API key, backend or private dependency is required.

## Sign and publish
Android Studio: **Build > Generate Signed Bundle / APK > Android App Bundle > app**, select or create your private upload keystore **outside this project**, enter credentials locally and choose release. Back up the keystore and passwords securely in separate protected locations. Reuse the same upload key for updates (or follow Play's official reset process); never commit it or send it in chat. Configure Play App Signing in Console. Command-line bundleRelease is unsigned unless you separately configure secure release signing. Keep the R8 mapping file from app/build/outputs/mapping/release/mapping.txt for each release.

Read PLAY_CONSOLE_CHECKLIST.md, STORE_LISTING.md, CHANGELOG.md, WORD_LIST_LICENSES.md, DEPENDENCIES.md and QA_REPORT.md. A successful build is not Play acceptance or phone validation.
