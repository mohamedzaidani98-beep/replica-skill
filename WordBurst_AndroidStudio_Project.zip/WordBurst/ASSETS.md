# Artwork inventory and replacement

This project uses hand-authored Android XML vector paths and a Compose W/B tile header based on the fixed brand and requested recognizable initials. No third-party art or copyrighted reference assets are downloaded. No fonts or sound recordings are bundled; the game uses system typography and locally generated tones.

The three images are visible in the conversation, but the upload exposed only the text brief as a downloadable attachment. Consequently the exact raster files `WordBurst_Icon_Original.png`, `WordBurst_Icon_512.png` and `WordBurst_Wordmark.png` are NOT included. Do not mistake a generated replacement for the originals.

To insert your originals: keep the high-resolution original in a new branding/ folder for design provenance; use Android Studio Image Asset with WordBurst_Icon_512.png to generate legacy mipmaps. For adaptive icons, use separate safe-zone foreground/background; do not simply put a fully framed square into the foreground. Existing foreground artwork stays inside central 54x54 of a 108x108 canvas. Adaptive XML: res/mipmap-anydpi-v26/ic_launcher.xml. Android 13 themed icon: res/mipmap-anydpi-v33/ic_launcher.xml and drawable/ic_monochrome.xml. Legacy vector: res/mipmap-anydpi/ic_launcher.xml. The launcher manifest points to @mipmap/ic_launcher.

Place the wordmark under res/drawable-nodpi/wordburst_wordmark.png and replace BrandHeader in ui/MenuScreens.kt with an Image using contentDescription="WordBurst", an adaptive width and preserved aspect ratio. Inspect on light/dark backgrounds, minimum icon masks and a small phone. Preserve the vector monochrome fallback for themed icons. No personal identity or metadata is intentionally embedded in the hand-authored vectors.
