# Original English Google Play draft

Title: **WordBurst**

Short description (under 80 characters):
Guess English words with bright clues, daily challenges and offline practice.

Full description:
Guess the word. Feel the burst.

Make a little room for a bright discovery. WordBurst gives you six attempts to uncover an English word, with clear clues after every guess.

Choose four, five or six letters. Find your pace in unlimited practice, or return for a daily challenge selected on your device. A thoughtful hint can reveal one position whenever you need a nudge, without costing an attempt.

WHAT'S INSIDE
• Offline core puzzles with a built-in English dictionary
• Three practice difficulties, including a repeated-letter challenge
• Daily puzzles for every word length
• Symbols and spoken labels alongside color clues
• Saved progress, statistics and daily streaks
• Light, dark and system themes, with optional strong tile outlines
• Optional sound and haptic feedback
• Spoiler-free result sharing

Your next clue is only a word away.

Core play does not require an account or an internet connection. Advertising, if enabled for your release, uses a network connection and is subject to privacy choices. Features and availability should be confirmed against the exact release configuration before publishing this draft.

## Screenshot shot list (capture from the actual app)
1. Colorful WordBurst menu with 4/5/6-letter selection and tagline.
2. Five-letter round with ✓/↔/× feedback and custom keyboard.
3. Six-letter repeated-letter puzzle demonstrating duplicate accounting.
4. Daily Challenge with saved local date and completed result.
5. Statistics with streak and guess distribution.
6. Dark theme and strong outlines at enlarged text size.
7. Settings with Privacy Options when actually required by UMP.

Use current Play Console screenshot dimensions; capture both compact phone and larger supported layouts. No screenshot renders, user counts, ratings or claims of Play acceptance are fabricated.
