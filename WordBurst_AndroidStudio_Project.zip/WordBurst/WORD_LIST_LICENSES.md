# Offline English word resources

Accepted guesses: Wordnik wordlist-20210729, https://github.com/wordnik/wordlist (MIT; copyright 2020 Wordnik). Full license in licenses/Wordnik-MIT.txt. Filtered to uppercase ASCII alphabetic words of lengths 4, 5 and 6; other entries removed. No reference-app corpus was used. This validation list includes uncommon dictionary words; answer candidates are a separately hand-selected common-word subset. Some inflections and uncommon spellings are valid guesses; dictionary completeness is not claimed.

Answer pools selected for this project and checked for membership in the licensed dictionary. Counts: {4: 617, 5: 772, 6: 679}. Accepted guesses: 35636.

Daily seed v1 depends on exact answer file order. Do not reorder/edit v1 pools for a shipped version without increasing the daily seed and record namespace and retaining old sessions. New installations with the same version/date/length agree locally. Local clock/time-zone changes can select a different day, not additional attempts for an existing date.

Upstream snapshot: commit 46e6215d0f90356afe9c8ba4be347e7e98cb425c. The frozen filtered answer files are shipped in this archive; the app never downloads corpus updates.
