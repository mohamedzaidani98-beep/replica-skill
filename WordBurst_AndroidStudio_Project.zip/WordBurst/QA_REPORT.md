# WordBurst QA report — 2026-10-23

This report distinguishes automated results, source inspection and device work that has not run. It does not claim Play acceptance or full raster-asset completion.

## VERIFIED

- Android build: bundled Gradle wrapper `./gradlew build bundleRelease assembleDebugAndroidTest` succeeded. Final application build: 147 actionable tasks (32 executed, 115 up-to-date). Debug APK, minified/shrunk unsigned release APK, unsigned release AAB and instrumentation APK were generated.
- JVM suites: **32 unique tests**, exercised in debug and release, zero failures/errors/skips. Duplicate-letter two-pass accounting, exact-first matching, invalid/short/repeated guesses, win/loss, legal non-downgrading keyboard clues, hints, no-repeat practice, dictionary adequacy, frozen daily vectors, midnight/date rollback, one record per date/length, typed input/repository recreation, settings, write-failure atomicity, sharing without answers, daily streaks and persisted ad caps are covered.
- Lint: zero errors. Two nonblocking warnings remain: a newer serialization JSON release exists (1.9.0 is pinned with the compatible Kotlin toolchain) and lint recommends a KTX edit helper (direct commit is intentionally retained so its boolean failure is checked).
- Android instrumentation sources compile and package. The custom test runner sets ads off before any Activity launches. Included device tests cover menu/play, typed input after recreation, save/leave and real Android preference-store reconstruction. **They have not been executed on a device.**
- Actual APK manifest inspection: appId com.zaidani.wordburst; name WordBurst; versionCode 1/versionName 1.0.0; min SDK 24; target/compile SDK 36.
- Actual debug/release permissions: INTERNET, ACCESS_NETWORK_STATE, WAKE_LOCK, FOREGROUND_SERVICE and the app-scoped AndroidX signature receiver permission. Wake-lock/background infrastructure originates in Google Ads/measurement/WorkManager. No location/camera/contacts/storage runtime permissions; advertising ID and AdServices ID/topics/attribution permissions removed. No gameplay foreground service is started.
- Generated debug BuildConfig uses only Google's official test IDs. Default release BuildConfig has ADS_ENABLED=false and empty runtime IDs. Manifest metadata uses the documented valid public sample app ID when disabled to satisfy the bundled SDK provider; this does not turn on monetization. Enabling production ads without IDs was actually attempted and failed with the intended clear error.
- Debug/release APK zip alignment checked with `zipalign -c -P 16 4`. Release AAB's arm64-v8a and x86_64 native path-renderer PT_LOAD segments are aligned to 16384 bytes. This is packaging/ELF inspection, not an actual 16 KB-device run or store validation.
- Six authored text/background contrast pairs pass AA (6.73:1–14.60:1). See replica/design/contrast-report.txt. This is not a complete rendered-screen accessibility audit.
- Google Play draft lint: title 9/30, short description 77/80, full description 1133/4000; zero errors/warnings.
- Source and APK byte-string scans found no obsolete brand, known Spanish UI phrases, reference package in the app, private-key/AWS-access-key patterns or personal/live ad IDs. The reference package URL is confined to research notes. Source binary inventory contains the Gradle wrapper; app images are hand-authored XML vectors. See replica/audit.json. Pattern checks are not a universal secret or natural-language detector.
- Offline corpus: 617 four-letter, 772 five-letter, 679 six-letter answer candidates; 35,636 accepted guesses. Every answer is accepted by the MIT-licensed Wordnik-derived validation list. Upstream license and snapshot attribution included.

## INSPECTED

- All app-authored labels, dialogs, tutorial, error messages, settings/privacy notes and store drafts are English. Activity resource configuration is explicitly English; system/SDK-owned surfaces may follow their own localization.
- Every input/action is committed as one SharedPreferences JSON document before in-memory state changes; every daily ID is date/length/seed-version scoped and completed stats are deduplicated. Unit tests recreate repositories using serialized snapshots; Android process death itself is not simulated here.
- Core word assets, rules and date selection are local. No game server, login, private Maven repository or personal secret is required. No proprietary reference corpus, binary, API, art or text was used.
- UMP sequence: requestConsentInfoUpdate → loadAndShowConsentFormIfRequired → canRequestAds; Privacy Options when REQUIRED. Initialization/request guards and player/consent/network gates exist. The SDK-ready state is observable across Activity recreation. All ad display/callback behavior still needs device validation.
- Banner only in a separate labelled main-menu region. Interstitial only on explicit optional transition from a completed practice round, after three completions and five minutes since last shown ad, with persisted caps. Normal Next never requires an ad. No daily, guess, back-navigation, launch or tutorial interstitial path exists. No rewarded ad gates hints/progress.
- Full dependency/license inventory includes 107 resolved release artifacts and Google SDK proprietary terms; Google measurement components are transitive SDK dependencies, not an app analytics integration. Do not assert that SDKs collect no data.

## NOT TESTED / remaining manual work

- No phone or emulator is supplied; /dev/kvm is absent. Instrumentation execution, physical offline launch, real process kill/restore, hardware keyboard behavior, rotation/background transitions, small-screen/large-font rendering, TalkBack and screenshot/icon appearance are **NOT TESTED**.
- Real Google test-ad serving/labels, consent acceptance/refusal/error/offline paths, geography, Privacy Options availability, SDK network traffic, form/ad rotation races, callbacks and actual frequency cap display are **NOT TESTED**. Follow ADS_AND_CONSENT.md and test on devices before enabling production ads.
- The three provided images were visible in the conversation but no raster file binaries were exposed for download. The exact PNGs are **not bundled**. An original adaptive W/B vector and monochrome fallback are included. Replace with the actual files using ASSETS.md if the exact raster branding is required.
- Release signing/upload, final name/store clearance, privacy policy hosting, SDK disclosures/Data safety, audience selection and Play prelaunch/internal testing remain manual. No keystore or passwords are bundled; AAB is unsigned.

## Reproduction environment

Temurin JDK 21.0.9+10 (the host originally had only a JRE), Gradle 8.13, AGP 8.13.2, Kotlin 2.2.21, SDK platform 36/build tools 36.0.0. JDK, Gradle and SDK archives were verified against official checksum sources; TLS verification stayed enabled. This sandbox uses external writable ANDROID_USER_HOME and GRADLE_USER_HOME and a system Java trust store/proxy outside the project. These machine-specific values are not in the ZIP. On Android Studio use its standard local JDK/SDK setup.

Public Play reference and developers.google.com documentation requests returned HTTP 403 in this instance. Scope therefore follows the detailed brief, not invented observations. Official Google Maven metadata and accessible official sample source informed integration. Exact supplied raster assets and real SDK behavior are not claimed as verified.

## Export verification — VERIFIED
The clean project ZIP was extracted under /tmp/wordburst-export-check. The included wrapper ran `testDebugUnitTest assembleDebug` without local.properties or retained build outputs: BUILD SUCCESSFUL in 14 seconds, all 46 tasks executed. All 32 tests passed again with zero failures/errors/skips. Only local JDK/SDK/cache environment paths were supplied externally. The archive was checked for ZIP integrity, required root files and absence of build directories, caches, signing keys and machine-specific local.properties.
