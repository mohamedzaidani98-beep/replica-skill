package studio.mossmosaic.ui
import androidx.compose.runtime.*
import studio.mossmosaic.game.*
class GameState {
 private val generator=PieceGenerator()
 var board by mutableStateOf(Board()); private set
 var pieces by mutableStateOf(generator.next(board)); private set
 var score by mutableIntStateOf(0); private set
 var combo by mutableIntStateOf(0); private set
 var selected by mutableIntStateOf(-1)
 var clearing by mutableStateOf(emptySet<Int>()); private set
 var busy by mutableStateOf(false); private set
 var over by mutableStateOf(false); private set
 fun begin(x: Int,y: Int): Boolean {
  if(busy || over) return false
  val shape=pieces.getOrNull(selected) ?: return false
  val move=Placement.apply(board,shape,x,y,selected+1) ?: return false
  busy=true; board=move.board; clearing=move.cleared; score+=move.points; combo=move.lines
  pieces=pieces.mapIndexed { i,s -> if(i==selected) null else s }; selected=-1
  return true
 }
 fun finish() {
  board=board.clear(clearing); clearing=emptySet()
  if(pieces.all { it==null }) pieces=generator.next(board)
  over=GameOver.check(board,pieces); busy=false
 }
}
