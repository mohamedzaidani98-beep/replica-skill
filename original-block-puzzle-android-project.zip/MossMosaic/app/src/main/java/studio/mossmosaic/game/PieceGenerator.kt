package studio.mossmosaic.game
import kotlin.random.Random
class PieceGenerator(seed: Long = System.nanoTime()) {
 private val random = Random(seed)
 fun next(board: Board): List<Shape?> {
  val fitting=Shapes.all.filter { board.canPlace(it) }
  // Guarantee one playable piece when space exists; other slots preserve challenge.
  return List(3) { i -> if(i==0 && fitting.isNotEmpty()) fitting.random(random) else Shapes.all.random(random) }
 }
}
