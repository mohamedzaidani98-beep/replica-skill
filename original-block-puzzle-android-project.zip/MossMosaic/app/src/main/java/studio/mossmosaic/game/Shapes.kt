package studio.mossmosaic.game

data class Cell(val x: Int, val y: Int)
data class Shape(val name: String, val cells: List<Cell>) {
 val width get() = cells.maxOf { it.x } + 1
 val height get() = cells.maxOf { it.y } + 1
}
object Shapes {
 private fun shape(name: String, vararg rows: String) = Shape(name, rows.flatMapIndexed { y, row -> row.mapIndexedNotNull { x, c -> if (c == '#') Cell(x,y) else null } })
 val all = listOf(shape("Seed", "#"), shape("Twig", "##"), shape("Stem", "#", "#", "#"), shape("Branch", "###"), shape("Long branch", "####"), shape("Tall stem", "#", "#", "#", "#"), shape("Garden", "##", "##"), shape("Corner", "#.", "#.", "##"), shape("Bent branch", "###", "..#"), shape("Canopy", "###", ".#."), shape("Zigzag", "##.", ".##"), shape("Stair", ".##", "##."), shape("Crown", "#.#", "###"), shape("Meadow", "###", "###"))
}
