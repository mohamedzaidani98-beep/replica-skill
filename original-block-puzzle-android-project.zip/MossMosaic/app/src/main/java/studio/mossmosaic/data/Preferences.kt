package studio.mossmosaic.data
import android.content.Context
object BestScore { fun updated(previous: Int,score: Int) = maxOf(previous,score) }
class Preferences(context: Context) {
 private val prefs=context.getSharedPreferences("moss_mosaic",Context.MODE_PRIVATE)
 var best: Int
  get()=prefs.getInt("best",0)
  set(value) { prefs.edit().putInt("best",BestScore.updated(best,value)).apply() }
 var sound: Boolean
  get()=prefs.getBoolean("sound",false)
  set(value) { prefs.edit().putBoolean("sound",value).apply() }
 var haptics: Boolean
  get()=prefs.getBoolean("haptics",true)
  set(value) { prefs.edit().putBoolean("haptics",value).apply() }
}
