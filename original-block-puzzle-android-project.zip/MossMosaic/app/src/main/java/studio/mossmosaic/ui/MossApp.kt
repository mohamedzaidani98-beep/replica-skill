package studio.mossmosaic.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import studio.mossmosaic.ads.AdConfig
import studio.mossmosaic.data.Preferences
import studio.mossmosaic.game.Cell
import studio.mossmosaic.settings.Feedback

@Composable fun MossApp() {
 val context=LocalContext.current; val view=LocalView.current
 val prefs=remember { Preferences(context) }; val feedback=remember { Feedback() }
 DisposableEffect(Unit) { onDispose { feedback.release() } }
 var best by remember { mutableIntStateOf(prefs.best) }
 var sound by remember { mutableStateOf(prefs.sound) }; var haptics by remember { mutableStateOf(prefs.haptics) }
 var screen by remember { mutableStateOf("menu") }
 var settings by rememberSaveable { mutableStateOf(false) }; var about by rememberSaveable { mutableStateOf(false) }
 var paused by remember { mutableStateOf(false) }
 var game by remember { mutableStateOf(GameState()) }
 var target by remember { mutableStateOf<Cell?>(null) }
 var notice by remember { mutableStateOf("Choose a piece, then a board cell.") }
 var startingBest by remember { mutableIntStateOf(best) }
 val scope=rememberCoroutineScope()
 fun start() { game=GameState(); target=null; notice="Choose a piece, then a board cell."; startingBest=best; paused=false; screen="game" }
 BackHandler(screen=="game") { paused=true }
 Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background) {
  Column(Modifier.safeDrawingPadding().fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp).widthIn(max=520.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(14.dp)) {
   when(screen) {
    "menu" -> {
     Spacer(Modifier.height(48.dp)); Text("✦",style=MaterialTheme.typography.displayLarge,color=MaterialTheme.colorScheme.primary)
     Text("MossMosaic",style=MaterialTheme.typography.headlineLarge)
     Text("A small garden of possibilities.",style=MaterialTheme.typography.bodyLarge)
     Spacer(Modifier.height(24.dp)); ScoreCard("PERSONAL BEST",best)
     Button(onClick={start()},modifier=Modifier.fillMaxWidth().height(56.dp)) { Text("Play") }
     OutlinedButton(onClick={settings=true},modifier=Modifier.fillMaxWidth()) { Text("Settings") }
     TextButton(onClick={about=true}) { Text("About") }
     Text("Offline • Unhurried • Yours",style=MaterialTheme.typography.labelLarge)
     if(AdConfig.enabled) AdPlaceholder()
    }
    "game" -> {
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
      Text("MossMosaic",style=MaterialTheme.typography.titleLarge)
      TextButton(onClick={paused=true}) { Text("Pause") }
     }
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) { ScoreCard("SCORE",game.score); ScoreCard("BEST",best) }
     Text(if(game.combo>1) "${game.combo} lines · +${studio.mossmosaic.game.Scoring.combo(game.combo)} harmony bonus" else if(game.combo==1) "A little room to grow" else "Find a place to grow",style=MaterialTheme.typography.titleSmall)
     BoardView(game,target) { target=it }
     Text(notice,style=MaterialTheme.typography.bodyMedium)
     PieceTray(game) { index -> game.selected=index; target=null; notice="Tap a cell for the top-left corner." }
     val shape=game.pieces.getOrNull(game.selected)
     val fits=shape!=null && target!=null && game.board.fits(shape,target!!.x,target!!.y)
     Button(onClick={
      val cell=target ?: return@Button
      if(game.begin(cell.x,cell.y)) {
       target=null; prefs.best=game.score; best=prefs.best
       feedback.play(view,sound,haptics,game.combo)
       scope.launch {
        delay(300); game.finish(); notice="Choose a piece, then a board cell."
        if(game.over) { AdConfig.afterCompletedGame(); screen="over" }
       }
      }
     },enabled=fits && !game.busy && !paused,modifier=Modifier.fillMaxWidth().height(52.dp)) { Text(if(target!=null && !fits) "This piece won't fit here" else "Place piece") }
    }
    "over" -> {
     Spacer(Modifier.height(40.dp)); Text("Garden complete",style=MaterialTheme.typography.headlineLarge)
     Text(if(game.score>startingBest) "A new personal best!" else "Every garden is a fresh start.")
     ScoreCard("FINAL SCORE",game.score); ScoreCard("BEST",best)
     Button(onClick={start()},modifier=Modifier.fillMaxWidth()) { Text("Grow again") }
     OutlinedButton(onClick={screen="menu"},modifier=Modifier.fillMaxWidth()) { Text("Main menu") }
     if(AdConfig.enabled) AdPlaceholder()
    }
   }
  }
 }
 if(settings) AlertDialog(onDismissRequest={settings=false},title={Text("Your pace")},text={Column {
  PreferenceToggle("Sound",sound) { sound=it; prefs.sound=it }
  PreferenceToggle("Haptic feedback",haptics) { haptics=it; prefs.haptics=it }
  Text("Sound starts off. Your choices stay on this device.")
 }},confirmButton={TextButton(onClick={settings=false}) { Text("Done") }})
 if(about) AlertDialog(onDismissRequest={about=false},title={Text("MossMosaic")},text={Text("An original offline puzzle. Fill rows or columns to make space. Clearing several lines together earns a harmony bonus. Pieces cannot rotate. No accounts, tracking or purchases.")},confirmButton={TextButton(onClick={about=false}) { Text("Close") }})
 if(paused && screen=="game") AlertDialog(onDismissRequest={paused=false},title={Text("Take a breath")},text={Text("Your board is waiting. Returning to the menu ends this garden.")},confirmButton={TextButton(onClick={paused=false}) { Text("Resume") }},dismissButton={TextButton(onClick={paused=false; screen="menu"}) { Text("End and return") }})
}
@Composable private fun ScoreCard(label: String,value: Int) {
 Column(horizontalAlignment=Alignment.CenterHorizontally) { Text(label,style=MaterialTheme.typography.labelMedium); Text(value.toString(),style=MaterialTheme.typography.headlineMedium) }
}
@Composable private fun PreferenceToggle(label: String,checked: Boolean,onChange: (Boolean)->Unit) {
 Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) { Text(label); Switch(checked=checked,onCheckedChange=onChange,modifier=Modifier.semanticsLabel(label)) }
}
private fun Modifier.semanticsLabel(label: String): Modifier = this.then(Modifier.semantics { contentDescription=label })
@Composable private fun AdPlaceholder() { OutlinedCard { Text("Optional sponsor space · ads inactive",Modifier.padding(16.dp)) } }
