package studio.mossmosaic.ui
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.Color
object Palette {
 val moss=Color(0xFF285847); val cream=Color(0xFFF6F2E8); val ink=Color(0xFF153E35)
 val pieces=listOf(Color(0xFF39775E),Color(0xFF9C5638),Color(0xFF65558A))
 val grid=Color(0xFFD7DFD2); val invalid=Color(0xFFAD2E35)
}
@Composable fun MossTheme(content: @Composable () -> Unit) {
 val colors=if(isSystemInDarkTheme()) darkColorScheme(primary=Color(0xFFB3D6BF),background=Color(0xFF12251E),surface=Color(0xFF1E342B)) else lightColorScheme(primary=Palette.moss,background=Palette.cream,surface=Palette.cream,onBackground=Palette.ink,onSurface=Palette.ink)
 MaterialTheme(colorScheme=colors,content=content)
}
