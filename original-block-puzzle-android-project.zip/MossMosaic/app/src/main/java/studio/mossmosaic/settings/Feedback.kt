package studio.mossmosaic.settings
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.HapticFeedbackConstants
import android.view.View
class Feedback {
 private var tone: ToneGenerator? = null
 fun play(view: View,sound: Boolean,haptics: Boolean,lines: Int) {
  if(haptics) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
  if(sound) runCatching {
   if(tone==null) tone=ToneGenerator(AudioManager.STREAM_MUSIC,35)
   tone?.startTone(if(lines>0) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP,90)
  }
 }
 fun release() { tone?.release(); tone=null }
}
