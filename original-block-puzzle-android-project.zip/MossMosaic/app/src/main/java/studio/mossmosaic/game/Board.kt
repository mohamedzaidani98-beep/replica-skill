package studio.mossmosaic.game

data class Board(val cells: List<Int> = List(64) { 0 }) {
 init { require(cells.size == 64) }
 operator fun get(x: Int,y: Int) = cells[y*8+x]
 fun fits(s: Shape,x: Int,y: Int) = s.cells.all { c -> x+c.x in 0..7 && y+c.y in 0..7 && get(x+c.x,y+c.y)==0 }
 fun canPlace(s: Shape) = (0..7).any { y -> (0..7).any { x -> fits(s,x,y) } }
 fun place(s: Shape,x: Int,y: Int,color: Int): Board {
  require(fits(s,x,y)); return Board(cells.toMutableList().apply { s.cells.forEach { this[(y+it.y)*8+x+it.x]=color } })
 }
 fun completed(): Set<Int> {
  val rows=(0..7).filter { y -> (0..7).all { x -> get(x,y)!=0 } }
  val cols=(0..7).filter { x -> (0..7).all { y -> get(x,y)!=0 } }
  return (rows.flatMap { y -> (0..7).map { x -> y*8+x } } + cols.flatMap { x -> (0..7).map { y -> y*8+x } }).toSet()
 }
 fun lineCount() = (0..7).count { y -> (0..7).all { get(it,y)!=0 } } + (0..7).count { x -> (0..7).all { get(x,it)!=0 } }
 fun clear(indices: Set<Int>) = Board(cells.mapIndexed { i,v -> if(i in indices) 0 else v })
}
