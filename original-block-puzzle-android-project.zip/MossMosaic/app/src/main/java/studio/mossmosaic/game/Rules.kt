package studio.mossmosaic.game

object Scoring {
 fun combo(lines: Int) = 25 * lines * (lines-1).coerceAtLeast(0)
 fun points(cells: Int, lines: Int) = cells*5 + lines*80 + combo(lines)
}
object GameOver { fun check(board: Board, pieces: List<Shape?>) = pieces.filterNotNull().none { board.canPlace(it) } }
data class Move(val board: Board,val cleared: Set<Int>,val lines: Int,val points: Int)
object Placement {
 fun apply(board: Board,shape: Shape,x: Int,y: Int,color: Int): Move? {
  if(!board.fits(shape,x,y)) return null
  val placed=board.place(shape,x,y,color); val lines=placed.lineCount()
  return Move(placed,placed.completed(),lines,Scoring.points(shape.cells.size,lines))
 }
}
