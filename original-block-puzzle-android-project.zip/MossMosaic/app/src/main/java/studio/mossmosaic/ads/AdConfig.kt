package studio.mossmosaic.ads
/** Integration-only configuration. No ads SDK or network permissions are bundled. */
object AdConfig {
 const val enabled = false
 const val interstitialEnabled = false
 const val applicationId = "ca-app-pub-3940256099942544~3347511713"
 const val bannerId = "ca-app-pub-3940256099942544/6300978111"
 const val interstitialId = "ca-app-pub-3940256099942544/1033173712"
 fun afterCompletedGame() { /* Integrate consent-gated SDK here; never during a move. */ }
}
