package studio.mossmosaic.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import studio.mossmosaic.game.*

@Composable fun BoardView(state: GameState, target: Cell?, onTarget: (Cell) -> Unit) {
 val shape=state.pieces.getOrNull(state.selected)
 val valid=shape!=null && target!=null && state.board.fits(shape,target.x,target.y)
 val preview=if(shape!=null && target!=null) shape.cells.map { Cell(it.x+target.x,it.y+target.y) }.toSet() else emptySet()
 Column(Modifier.fillMaxWidth().aspectRatio(1f).testTag("board").semantics { contentDescription="Game board, 8 rows and 8 columns" }.background(Palette.ink,RoundedCornerShape(18.dp)).padding(8.dp),verticalArrangement=Arrangement.spacedBy(3.dp)) {
  repeat(8) { y -> Row(Modifier.weight(1f),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
   repeat(8) { x ->
    val value=state.board[x,y]; val here=Cell(x,y) in preview
    val color by animateColorAsState(if(here) { if(valid) Palette.moss else Palette.invalid } else if(value==0) Palette.grid else Palette.pieces[(value-1)%3],tween(160),label="Cell color")
    val fade by animateFloatAsState(if(y*8+x in state.clearing) 0.12f else 1f,tween(240),label="Clear line")
    Box(Modifier.weight(1f).fillMaxHeight().alpha(fade).background(Brush.linearGradient(listOf(color,color.copy(alpha=0.78f))),RoundedCornerShape(4.dp)).then(if(here) Modifier.border(2.dp,if(valid) Color.White else Palette.invalid,RoundedCornerShape(4.dp)) else Modifier).clickable(enabled=!state.busy && shape!=null) { onTarget(Cell(x,y)) }.semantics { contentDescription="Row ${y+1}, column ${x+1}, ${if(value==0) "empty" else "occupied"}" })
   }
  } }
 }
}

@Composable fun PieceTray(state: GameState,onSelect: (Int)->Unit) {
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
  state.pieces.forEachIndexed { index,shape ->
   OutlinedCard(onClick={onSelect(index)},enabled=shape!=null && !state.busy,modifier=Modifier.weight(1f).height(104.dp).semantics { contentDescription=if(shape==null) "Piece ${index+1} used" else "Select ${shape.name}, ${shape.cells.size} cells" },border=androidx.compose.foundation.BorderStroke(if(state.selected==index) 3.dp else 1.dp,if(state.selected==index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)) {
    Box(Modifier.fillMaxSize().padding(12.dp),contentAlignment=androidx.compose.ui.Alignment.Center) {
     if(shape!=null) Column(verticalArrangement=Arrangement.spacedBy(2.dp)) {
      repeat(shape.height) { y -> Row(horizontalArrangement=Arrangement.spacedBy(2.dp)) { repeat(shape.width) { x ->
       Box(Modifier.size(14.dp).background(if(Cell(x,y) in shape.cells) Palette.pieces[index] else Color.Transparent,RoundedCornerShape(3.dp)))
      } } }
     } else Text("✓")
    }
   }
  }
 }
}
