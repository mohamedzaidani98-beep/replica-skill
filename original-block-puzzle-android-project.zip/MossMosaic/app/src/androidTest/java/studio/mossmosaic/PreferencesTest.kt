package studio.mossmosaic
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import studio.mossmosaic.data.Preferences
class PreferencesTest {
 @Test fun recordAndSettingsSurviveNewRepositoryInstance() {
  val context=InstrumentationRegistry.getInstrumentation().targetContext
  context.getSharedPreferences("moss_mosaic",0).edit().clear().commit()
  val first=Preferences(context); first.best=120; first.best=10; first.sound=true; first.haptics=false
  val second=Preferences(context)
  assertEquals(120,second.best); assertTrue(second.sound); assertFalse(second.haptics)
 }
}
