package studio.mossmosaic
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
class MenuTest {
 @get:Rule val compose=createAndroidComposeRule<MainActivity>()
 @Test fun opensMenuAndStartsBoard() {
  compose.onNodeWithText("MossMosaic").assertIsDisplayed()
  compose.onNodeWithText("Play").performClick()
  compose.onNodeWithTag("board").assertIsDisplayed()
  compose.onAllNodes(hasContentDescription("Row ",substring=true)).assertCountEquals(64)
  compose.onNodeWithText("Pause").performClick()
  compose.onNodeWithText("End and return").performClick()
  compose.onNodeWithText("Play").assertIsDisplayed()
 }
}
