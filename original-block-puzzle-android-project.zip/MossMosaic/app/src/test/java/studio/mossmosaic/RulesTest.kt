package studio.mossmosaic
import org.junit.Assert.*
import org.junit.Test
import studio.mossmosaic.game.*
import studio.mossmosaic.data.BestScore
class RulesTest {
 private val single=Shapes.all[0]
 private fun filled(indices: Set<Int>)=Board(List(64) { if(it in indices) 1 else 0 })
 @Test fun validPlacement() { assertTrue(Board().fits(single,7,7)); assertEquals(1,Board().place(single,7,7,1)[7,7]) }
 @Test fun occupiedIsInvalid() { assertFalse(filled(setOf(0)).fits(single,0,0)); assertNull(Placement.apply(filled(setOf(0)),single,0,0,1)) }
 @Test fun boundaries() { assertFalse(Board().fits(single,-1,0)); assertFalse(Board().fits(single,0,8)); assertFalse(Board().fits(Shapes.all[1],7,0)) }
 @Test fun rowClearing() { val b=filled((0..7).toSet()); assertEquals(1,b.lineCount()); assertEquals(8,b.completed().size); assertTrue(b.clear(b.completed()).cells.all { it==0 }) }
 @Test fun columnClearing() { val b=filled((0..7).map { it*8 }.toSet()); assertEquals(1,b.lineCount()); assertEquals(8,b.completed().size); assertTrue(b.clear(b.completed()).cells.all { it==0 }) }
 @Test fun simultaneousClearing() {
  val indices=((0..7).toList()+(0..7).map { it*8 }).toSet()
  val before=filled(indices-setOf(0)); val move=Placement.apply(before,single,0,0,1)!!
  assertEquals(2,move.lines); assertEquals(15,move.cleared.size); assertTrue(move.board.clear(move.cleared).cells.all { it==0 }); assertEquals(215,move.points)
 }
 @Test fun preservesOtherCells() { val b=filled((0..7).toSet()+63); assertEquals(1,b.clear(b.completed())[7,7]) }
 @Test fun score() { assertEquals(15,Scoring.points(3,0)); assertEquals(95,Scoring.points(3,1)) }
 @Test fun combo() { assertEquals(0,Scoring.combo(0)); assertEquals(0,Scoring.combo(1)); assertEquals(50,Scoring.combo(2)); assertEquals(150,Scoring.combo(3)) }
 @Test fun gameOver() { assertTrue(GameOver.check(filled((0..63).toSet()),listOf(single))); assertFalse(GameOver.check(Board(),listOf(null,single,null))) }
 @Test fun awkwardHole() { val b=filled((0..63).toSet()-0); assertTrue(GameOver.check(b,listOf(Shapes.all[1]))); assertFalse(GameOver.check(b,listOf(single))) }
 @Test fun bestNeverDecreases() { assertEquals(90,BestScore.updated(90,20)); assertEquals(100,BestScore.updated(90,100)) }
 @Test fun generationIsSeededAndPlayable() { assertEquals(PieceGenerator(17).next(Board()),PieceGenerator(17).next(Board())); val b=filled((0..63).toSet()-0); assertTrue(PieceGenerator(8).next(b).filterNotNull().any { b.canPlace(it) }) }
 @Test fun stateRefillsAfterThreePieces() { val state=studio.mossmosaic.ui.GameState(); repeat(3) { i -> state.selected=i; val shape=state.pieces[i]!!; val cell=(0..7).flatMap { y -> (0..7).map { x -> Cell(x,y) } }.first { state.board.fits(shape,it.x,it.y) }; assertTrue(state.begin(cell.x,cell.y)); state.finish() }; assertEquals(3,state.pieces.filterNotNull().size) }
}
