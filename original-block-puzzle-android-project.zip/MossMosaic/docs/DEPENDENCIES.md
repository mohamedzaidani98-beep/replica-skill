# Dependencies and licenses
Direct build/runtime dependencies: Android Gradle Plugin 8.7.3 (Apache-2.0), Gradle 8.9 (Apache-2.0), Kotlin and Compose compiler plugin 2.0.21 (Apache-2.0), Kotlin standard library (Apache-2.0), AndroidX Activity Compose 1.9.3 (Apache-2.0), Compose BOM 2024.12.01 with Compose UI/runtime/foundation/material3/tooling (Apache-2.0). Android platform SDK/build tools are governed by the Android SDK license accepted during installation.

Tests: JUnit 4.13.2 (EPL-1.0), Hamcrest (BSD-3-Clause), AndroidX Test runner 1.6.2 and ext JUnit 1.2.1 and Compose UI tests (Apache-2.0). AndroidX/Kotlin transitive libraries retain their Apache-2.0 notices; Gradle dependency metadata supplies their exact versions and license links. Run ./gradlew :app:dependencies for the full resolved graph. No AdMob dependency is included. No third-party artwork, fonts or audio is bundled; Android system fonts are used. Before distribution retain applicable dependency license and NOTICE files and audit the release dependency graph.

## Resolved release libraries (including transitive)

| Artifact | License |
| --- | --- |
| androidx.activity:activity-compose:1.9.3@aar | Apache-2.0 |
| androidx.activity:activity-ktx:1.9.3@aar | Apache-2.0 |
| androidx.activity:activity:1.9.3@aar | Apache-2.0 |
| androidx.annotation:annotation-experimental:1.4.1@aar | Apache-2.0 |
| androidx.annotation:annotation-jvm:1.8.1@jar | Apache-2.0 |
| androidx.arch.core:core-common:2.2.0@jar | Apache-2.0 |
| androidx.arch.core:core-runtime:2.2.0@aar | Apache-2.0 |
| androidx.autofill:autofill:1.0.0@aar | Apache-2.0 |
| androidx.collection:collection-jvm:1.4.4@jar | Apache-2.0 |
| androidx.collection:collection-ktx:1.4.4@jar | Apache-2.0 |
| androidx.compose.animation:animation-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.animation:animation-core-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.foundation:foundation-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.foundation:foundation-layout-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.material3:material3-android:1.3.1@aar | Apache-2.0 |
| androidx.compose.material:material-icons-core-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.material:material-ripple-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.runtime:runtime-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.runtime:runtime-saveable-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.ui:ui-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.ui:ui-geometry-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.ui:ui-graphics-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.ui:ui-text-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.ui:ui-tooling-preview-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.ui:ui-unit-android:1.7.6@aar | Apache-2.0 |
| androidx.compose.ui:ui-util-android:1.7.6@aar | Apache-2.0 |
| androidx.concurrent:concurrent-futures:1.1.0@jar | Apache-2.0 |
| androidx.core:core-ktx:1.13.1@aar | Apache-2.0 |
| androidx.core:core:1.13.1@aar | Apache-2.0 |
| androidx.customview:customview-poolingcontainer:1.0.0@aar | Apache-2.0 |
| androidx.emoji2:emoji2:1.3.0@aar | Apache-2.0 |
| androidx.graphics:graphics-path:1.0.1@aar | Apache-2.0 |
| androidx.interpolator:interpolator:1.0.0@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-common-java8:2.8.3@jar | Apache-2.0 |
| androidx.lifecycle:lifecycle-common-jvm:2.8.3@jar | Apache-2.0 |
| androidx.lifecycle:lifecycle-livedata-core:2.8.3@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-process:2.8.3@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-runtime-android:2.8.3@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-runtime-compose-android:2.8.3@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-runtime-ktx-android:2.8.3@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-viewmodel-android:2.8.3@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.3@aar | Apache-2.0 |
| androidx.lifecycle:lifecycle-viewmodel-savedstate:2.8.3@aar | Apache-2.0 |
| androidx.profileinstaller:profileinstaller:1.3.1@aar | Apache-2.0 |
| androidx.savedstate:savedstate-ktx:1.2.1@aar | Apache-2.0 |
| androidx.savedstate:savedstate:1.2.1@aar | Apache-2.0 |
| androidx.startup:startup-runtime:1.1.1@aar | Apache-2.0 |
| androidx.tracing:tracing:1.0.0@aar | Apache-2.0 |
| androidx.versionedparcelable:versionedparcelable:1.1.1@aar | Apache-2.0 |
| com.google.guava:listenablefuture:1.0@jar | Apache-2.0 |
| org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.20@jar | Apache-2.0 |
| org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.20@jar | Apache-2.0 |
| org.jetbrains.kotlin:kotlin-stdlib:2.0.21@jar | Apache-2.0 |
| org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3@jar | Apache-2.0 |
| org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm:1.7.3@jar | Apache-2.0 |
| org.jetbrains:annotations:23.0.0@jar | Apache-2.0 |
