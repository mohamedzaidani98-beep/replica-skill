# Architecture
Kotlin 2.0.21, Compose compiler plugin, Material 3, AGP 8.7.3, Gradle 8.9, SDK 35, minimum 24. No backend, database or private APIs.

Board is an immutable 64-cell list. Shapes contains cell offsets. Placement validates and returns a move with simultaneous clear indices and points. Scoring and GameOver are separate pure policies. PieceGenerator uses an injectable deterministic seed and guarantees one fitting shape when space exists. GameState owns reactive UI state and commits clearing after a 300ms animation window. Inputs are locked during that transaction.

MossApp routes menu, game and result screens, coordinates persistence and original generated audio. BoardView animates cell colors and line fade. Preferences uses private SharedPreferences and monotonic BestScore logic. Activity recreation resets the current session by design; record and preferences survive. Pausing hides the board with a modal and prevents confirmation. Ads configuration is inert, with no SDK in the shipped dependency graph.
