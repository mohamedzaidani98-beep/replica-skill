# Validation evidence

Validated in the cloud workspace on 2026-10-20 using Java 21.0.12.1, Android SDK 35/build tools 35.0.0, Kotlin 2.0.21, AGP 8.7.3 and the included Gradle 8.9 wrapper.

- `./gradlew build bundleRelease assembleDebugAndroidTest`: SUCCESS (135 tasks; 53 executed, 82 up-to-date in final run).
- Debug JVM suite: 14 tests, zero failures/errors/skips. Release JVM suite: same 14 tests, zero failures/errors/skips. These are 14 unique tests exercised in both variants.
- Debug APK and unsigned release AAB packaged successfully. Android test APK compiled and packaged successfully.
- Lint passed with zero errors. Two warnings intentionally remain for the requested portrait lock; large-screen/Chrome OS adaptation is a future enhancement.
- Original palette contrast: five checked text/background pairs passed AA (ratios 5.84–12.36). See replica/design/contrast-report.txt.
- Brand sweep of shipped project: clean for reference name/publisher. No copied reference artwork or audio.
- Manifest inspection: package studio.mossmosaic, min SDK 24, target/compile SDK 35. No INTERNET, advertising ID, location or runtime permissions. AndroidX adds only its app-scoped internal signature permission.
- The Replica skills checkout remained unchanged.

Device tests are NOT EXECUTED. No emulator/physical device is supplied; this host lacks /dev/kvm and adb cannot initialize its default home directory in the sandbox. No device or screenshot-based visual validation is claimed. Run `./gradlew connectedDebugAndroidTest` on a configured phone/emulator. Menu/game-board flow and durable preference instrumentation tests are included. Game-over restart, TalkBack, airplane-mode use, compact screens and process recreation need a phone check before release.

The sandbox needs writable tooling directories: ANDROID_USER_HOME=/workspace/android-user and GRADLE_USER_HOME=/workspace/gradle-home. Its Java network proxy is configured outside the project; no proxy settings or credentials are bundled. On a normal Android Studio machine use its SDK location and standard Gradle user home. SDK archives were downloaded from Google and verified against official repository checksums; Gradle's wrapper pins its distribution SHA-256. TLS verification remained enabled.

The release bundle is unsigned. No signing keys, credentials, build directories, caches or machine-specific local.properties are included in the project archive. Store publication and name clearance have not been performed.

Archive reproducibility: extracted the clean ZIP under /tmp/moss-archive-check and ran the included wrapper with testDebugUnitTest assembleDebug and ANDROID_HOME pointing to the installed SDK. SUCCESS in 8 seconds, 41 executed tasks. All 14 tests passed again with zero failures/errors/skips. No local.properties or retained build outputs were needed.
