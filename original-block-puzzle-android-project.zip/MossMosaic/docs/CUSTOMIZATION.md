# Customization
Change strings.xml and the MossApp title for a new display name. Rename packages with Android Studio's refactor tools, update applicationId and namespace, and update the tests. Replace ic_moss.xml with your own vector or generated icon. The existing icon is an original three-tile and leaf composition.

Theme.kt holds light/dark colors and the three tray pigments. BoardView.kt holds rounding, gradients, spacing and transitions. Respect body-text contrast and check small phones and larger system fonts. Board cells use proportional weights, while the screen scrolls on compact displays. Shapes.kt defines '#' footprints; each shape must be nonempty with nonnegative offsets. Rules.kt contains points and bonus math. PieceGenerator(seed) enables repeatable engine tests.

The working name is not trademark-cleared. Before release, search relevant trademark registries and app stores and choose a cleared identity. No reference artwork, sounds, code or store copy is included.
