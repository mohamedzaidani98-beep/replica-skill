# MossMosaic implementation plan

1. Use only the supplied gameplay brief as functional evidence; public reference URL: https://play.google.com/store/apps/details?id=com.block.juggle&hl=en . No proprietary assets, code or visual measurements are used.
2. Build pure Kotlin immutable board, shape catalog, seeded piece generator, simultaneous line clearing, scoring and game-over rules. Cover these with JVM unit tests.
3. Build portrait Compose menu, responsive 8x8 board with tap placement and hover preview, three-piece tray, pause, settings and results. Animate placement and clearing. Use original moss, cream and copper tokens and a procedural leaf-grid icon.
4. Store best score and preferences locally. Use optional generated tones and device haptics. Prepare disabled ad integration hooks without adding a network SDK.
5. Build APK, AAB and UI test APK; run JVM tests and device tests if a device is available. Document exact evidence and limitations. Package a clean Android Studio root with Gradle wrapper.

Required: working engine, screens, persistence, JVM tests, APK/AAB. Device UI execution requires a connected device or emulator. Drag placement is optional; accessible tap selection and placement is the primary supported interaction. Trademark searches for the temporary working name remain a release step.
