# MossMosaic

An original offline garden-themed 8x8 puzzle, written in Kotlin and Jetpack Compose. Temporary working name; store and trademark clearance is not claimed.

## Open and run
Open this folder (containing settings.gradle.kts) in Android Studio. Use JDK 17 or 21, install Android SDK 35 and accept SDK licenses. Let Gradle sync finish. Android Studio supplies your local SDK path in local.properties. No keys or server needed.

Connect an Android 7.0+ phone, enable Developer options and USB debugging, approve the computer, select the phone and press Run. Use a recent Android Studio release supporting AGP 8.7.3. On Windows use gradlew.bat in place of ./gradlew.

```sh
./gradlew build
./gradlew testDebugUnitTest
./gradlew assembleDebug
./gradlew bundleRelease
./gradlew connectedDebugAndroidTest
```

Debug APK: app/build/outputs/apk/debug/app-debug.apk. Release bundle: app/build/outputs/bundle/release/app-release.aab (unsigned until configured). Device tests need an emulator or phone. See docs/RELEASE.md for signing.

## Play
Tap one of three pieces, tap a board cell to preview its top-left corner, then tap Place piece. Green preview is valid; red is blocked. Complete rows and columns together for a harmony bonus. Use all three pieces for a fresh tray. No rotation, timer, login or purchases. System dark theme is supported. Sound is off by default; settings persist on this device. A running board is in memory and resets after activity/process recreation; best score and preferences persist.

## Customize
- App name: app/src/main/res/values/strings.xml and the visible titles in ui/MossApp.kt.
- Package: Android Studio Refactor > Rename studio.mossmosaic, then update namespace/applicationId in app/build.gradle.kts and test packages.
- Icon: app/src/main/res/drawable/ic_moss.xml; alternatively use Image Asset and update the manifest icon reference.
- Colors and theme: ui/Theme.kt; block appearance: ui/BoardView.kt.
- Rules: game/Board.kt, Rules.kt, Shapes.kt and PieceGenerator.kt.
- Ads: ads/AdConfig.kt. Disabled by default; changing enabled shows a placeholder only, not live advertising. See docs/ADMOB.md for SDK, consent and manifest integration.

See docs/ARCHITECTURE.md, GAMEPLAY.md, CUSTOMIZATION.md, PRIVACY.md and DEPENDENCIES.md. PLAN.md records implementation order. docs/VALIDATION.md records actual build evidence.
