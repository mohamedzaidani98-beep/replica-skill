# Scope and sources
Source: user-provided detailed functional brief. Public reference URL supplied: https://play.google.com/store/apps/details?id=com.block.juggle&hl=en . No reference screenshots/assets downloaded or binary inspected. No claims about unobserved reference features.

S01 menu: play, record, settings, about. S02 garden: score, record, 8x8 board, tray, confirmation, pause. S03 results: score, record, restart/menu. S04 settings modal: audio/haptics. F01 start/select/preview/place/clear/refill. F02 no moves/results/restart. F03 change preferences/relaunch. F04 pause/resume/exit.

Entities: board cells, immutable shape offsets, tray, score, preferences. Highest risks: simultaneous crossing lines, move locking during animation, process lifecycle. Out of scope: reference branding, online services, accounts, monetization rollout and rotation. All artwork is procedural and original. Native Kotlin/Compose chosen per explicit brief.
