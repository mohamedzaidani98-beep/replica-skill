# Working identity
MossMosaic: quiet, clear, playful. Original leaf and tile mark, moss/cream/copper/purple pigments, original generated tones. This is a temporary working name. Trademark, domain, store and handle checks are TO RUN before publication; availability is not asserted. No affiliation with any reference publisher.
